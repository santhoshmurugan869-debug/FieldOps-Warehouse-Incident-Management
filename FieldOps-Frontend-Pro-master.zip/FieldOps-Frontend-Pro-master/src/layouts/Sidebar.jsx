// ====================================================================
// FIELDOPS - SIDEBAR NAVIGATION COMPONENT
// ====================================================================

import React from 'react';
import { 
  LayoutDashboard, 
  PlusCircle, 
  ClipboardList, 
  Bell, 
  User, 
  BookOpen, 
  Package, 
  LogOut,
  ChevronRight,
  Radio
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useIncidents } from '../context/IncidentContext';
import WorkerAvatar from '../components/WorkerAvatar';

export default function Sidebar({ currentTab, setTab, isMobile = false, onCloseMobile }) {
  const { currentWorker, logout } = useAuth();
  const { notifications } = useIncidents();

  const unreadCount = notifications.filter(n => !n.read).length;

  const NAV_ITEMS = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'report', label: 'Report Incident', icon: PlusCircle, highlight: true },
    { id: 'incidents', label: 'My Incidents', icon: ClipboardList },
    { id: 'notifications', label: 'Notifications', icon: Bell, badge: unreadCount },
    { id: 'profile', label: 'Worker Profile', icon: User },
    { id: 'sop', label: 'Help / SOP Guidelines', icon: BookOpen }
  ];

  const handleSelect = (id) => {
    setTab(id);
    if (isMobile && onCloseMobile) {
      onCloseMobile();
    }
  };

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col h-full select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold tracking-tight text-slate-900">FieldOps</h1>
              <span className="text-[10px] font-semibold uppercase bg-blue-50 text-blue-700 px-1.5 py-0.2 rounded border border-blue-200">
                WMS
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Work Coordination</p>
          </div>
        </div>
      </div>

      {/* Main Navigation Links */}
      <div className="p-3 flex-1 overflow-y-auto space-y-1">
        <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
          Warehouse Operations
        </div>

        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => handleSelect(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-blue-50/80 text-blue-700 border border-blue-200/80 shadow-2xs'
                  : item.highlight
                  ? 'text-blue-600 hover:bg-blue-50/40'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </div>

              {item.badge > 0 && (
                <span className="px-1.5 py-0.5 rounded-full text-[11px] font-bold bg-blue-600 text-white min-w-[20px] text-center">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Warehouse System Status Pill */}
      <div className="px-4 py-2 mx-3 mb-2 rounded-lg bg-emerald-50/80 border border-emerald-200 text-emerald-800 text-[11px] flex items-center justify-between">
        <span className="flex items-center gap-1.5 font-medium">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>SNS Agent Active</span>
        </span>
        <span className="text-[10px] text-emerald-700 font-mono">v2.4</span>
      </div>

      {/* Authenticated Worker Footer */}
      <div className="p-3 border-t border-slate-100 bg-slate-50/70 flex items-center justify-between gap-1">
        <div 
          onClick={() => handleSelect('profile')}
          className="flex-1 flex items-center gap-2.5 p-1.5 rounded-xl hover:bg-white hover:border hover:border-slate-200 cursor-pointer transition-all min-w-0"
        >
          <WorkerAvatar name={currentWorker?.full_name} id={currentWorker?.worker_id} size="sm" />
          <div className="min-w-0 text-left">
            <p className="text-xs font-semibold text-slate-800 truncate">
              {currentWorker?.full_name || 'Worker'}
            </p>
            <p className="text-[11px] text-slate-400 font-mono truncate">
              {currentWorker?.worker_id || 'ID'}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={logout}
          title="Sign out of station"
          className="p-2 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors shrink-0"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
}
