// ====================================================================
// FIELDOPS - TOPBAR COMPONENT
// ====================================================================

import React from 'react';
import { 
  Menu, 
  Plus, 
  Bell, 
  MapPin, 
  Radio, 
  Users, 
  CheckCircle2 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useIncidents } from '../context/IncidentContext';
import WorkerAvatar from '../components/WorkerAvatar';

export default function Topbar({ onOpenMobileMenu, onOpenReport, currentTab, setTab }) {
  const { currentWorker } = useAuth();
  const { notifications } = useIncidents();

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30">
      {/* Left: Mobile hamburger & Location indicator */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="p-2 -ml-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 md:hidden"
          aria-label="Open sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* Location pill */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100/90 border border-slate-200 text-xs text-slate-700">
          <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
          <span className="font-medium truncate max-w-[140px] sm:max-w-none">
            {currentWorker?.warehouse_location || 'Packing Warehouse'}
          </span>
        </div>
      </div>

      {/* Right: Quick actions, notifications, and worker pill */}
      <div className="flex items-center gap-2.5 sm:gap-3">
        {/* Quick Report Button */}
        <button
          type="button"
          onClick={onOpenReport}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden xs:inline">Report Incident</span>
        </button>

        {/* Notifications Icon Button */}
        <button
          type="button"
          onClick={() => setTab('notifications')}
          className="relative p-2 rounded-lg text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
          aria-label="View notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-blue-600 ring-2 ring-white" />
          )}
        </button>

        {/* Worker Switcher / Identity Badge */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
          <button
            type="button"
            onClick={() => setTab('profile')}
            className="flex items-center gap-2 p-1 rounded-lg hover:bg-slate-50 text-left transition-colors"
          >
            <WorkerAvatar name={currentWorker?.full_name} id={currentWorker?.worker_id} size="sm" />
            <div className="hidden lg:block">
              <p className="text-xs font-semibold text-slate-800 leading-tight">
                {currentWorker?.full_name}
              </p>
              <p className="text-[10px] text-slate-400 font-mono">
                {currentWorker?.worker_id}
              </p>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}
