// ====================================================================
// FIELDOPS - APPLICATION SHELL & LAYOUT
// ====================================================================

import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import ToastContainer from '../components/Toast';

export default function AppLayout({ currentTab, setTab, children }) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Sidebar (hidden on mobile) */}
      <div className="hidden md:block w-64 shrink-0 h-screen sticky top-0 z-40">
        <Sidebar currentTab={currentTab} setTab={setTab} />
      </div>

      {/* Mobile Drawer Backdrop & Sidebar */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 w-64 bg-white shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            <Sidebar
              currentTab={currentTab}
              setTab={setTab}
              isMobile={true}
              onCloseMobile={() => setIsMobileMenuOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          currentTab={currentTab}
          setTab={setTab}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          onOpenReport={() => setTab('report')}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>

      {/* Global Toast Alerts */}
      <ToastContainer />
    </div>
  );
}
