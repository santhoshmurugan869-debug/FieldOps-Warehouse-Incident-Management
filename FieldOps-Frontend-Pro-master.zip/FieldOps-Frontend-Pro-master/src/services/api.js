// ====================================================================
// FIELDOPS - API & SNS AGENT WORKBENCH WEBHOOK INTEGRATION
// ====================================================================

const DEFAULT_WEBHOOK_URL = 'https://api.agents.snsihub.ai/webhook-test/FIELD%20OPS';

/**
 * Get current configured webhook URL
 */
export function getWebhookUrl() {
  const url = import.meta.env.VITE_FIELDOPS_WEBHOOK_URL || DEFAULT_WEBHOOK_URL;
  return encodeURI(decodeURI(url));
}

/**
 * Submit Text Incident to SNS Agent Workbench
 * 
 * Payload structure:
 * {
 *   "report_mode": "text",
 *   "worker_id": "WKR-001",
 *   "worker_name": "Arun Kumar",
 *   "incident_type": "Machine Down",
 *   "location": "Packing Area",
 *   "impact": "Packing machine stopped and around 30 orders are delayed."
 * }
 */
export async function submitTextIncident({ worker_id, worker_name, incident_type, location, impact }) {
  if (!worker_id || !worker_name) {
    throw new Error('Worker identity is required to submit an incident report.');
  }
  if (!incident_type || !location || !impact) {
    throw new Error('Please fill in Incident Type, Location, and Impact.');
  }

  const payload = {
    report_mode: 'text',
    worker_id,
    worker_name,
    incident_type,
    location,
    impact,
    timestamp: new Date().toISOString()
  };

  const webhookUrl = getWebhookUrl();

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout

    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    let resultData = null;
    try {
      resultData = await response.json();
    } catch {
      // Some webhooks return plain text or empty body
      resultData = { status: 'submitted' };
    }

    if (!response.ok) {
      console.warn(`Webhook returned HTTP status ${response.status}`, resultData);
      // Even if webhook returned non-200, return structured data with flag
      return {
        success: false,
        status: response.status,
        message: resultData?.message || `Webhook responded with status ${response.status}`,
        data: resultData
      };
    }

    return {
      success: true,
      status: response.status,
      data: resultData
    };
  } catch (error) {
    console.error('Webhook dispatch error:', error);
    const isAbort = error.name === 'AbortError';
    return {
      success: false,
      isNetworkError: true,
      message: isAbort 
        ? 'Webhook request timed out. Please verify your connection.'
        : 'Unable to reach SNS Agent Workbench webhook. Saved locally for synchronization.',
      error: error.message
    };
  }
}

/**
 * Submit Voice Incident to SNS Agent Workbench
 * 
 * Submits multipart/form-data:
 * - report_mode: "voice"
 * - worker_id
 * - worker_name
 * - audio: Audio file blob
 */
export async function submitVoiceIncident({ worker_id, worker_name, audioBlob, location = 'Warehouse Floor' }) {
  if (!worker_id || !worker_name) {
    throw new Error('Worker identity is required for voice reports.');
  }
  if (!audioBlob) {
    throw new Error('No recorded audio file was provided.');
  }

  const formData = new FormData();
  formData.append('report_mode', 'voice');
  formData.append('worker_id', worker_id);
  formData.append('worker_name', worker_name);
  formData.append('location', location);
  formData.append('timestamp', new Date().toISOString());

  const filename = `voice-report-${worker_id}-${Date.now()}.webm`;
  formData.append('audio', audioBlob, filename);

  const webhookUrl = getWebhookUrl();

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 20000); // 20s timeout for voice

    const response = await fetch(webhookUrl, {
      method: 'POST',
      body: formData,
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    let resultData = null;
    try {
      resultData = await response.json();
    } catch {
      resultData = { status: 'submitted' };
    }

    if (!response.ok) {
      console.warn(`Voice webhook returned status ${response.status}`, resultData);
      return {
        success: false,
        status: response.status,
        message: resultData?.message || `Webhook error (${response.status})`,
        data: resultData
      };
    }

    return {
      success: true,
      status: response.status,
      data: resultData
    };
  } catch (error) {
    console.error('Voice webhook dispatch error:', error);
    return {
      success: false,
      isNetworkError: true,
      message: 'Unable to upload voice report to webhook. Incident recorded locally.',
      error: error.message
    };
  }
}
