// ====================================================================
// FIELDOPS - SUPABASE CLIENT & DATA LAYER
// ====================================================================

import { createClient } from '@supabase/supabase-js';
import { LocalStorage } from '../utils/storage';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Check if valid credentials are provided
const isConfigured = Boolean(
  supabaseUrl && 
  supabaseAnonKey && 
  supabaseUrl.startsWith('https://') &&
  !supabaseUrl.includes('your-project')
);

export const supabase = isConfigured 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

if (isConfigured) {
  console.info('[FieldOps] Connected to Supabase backend.');
} else {
  console.info('[FieldOps] Running with local operational persistence engine (Supabase keys unset or demo mode).');
}

/**
 * Fetch all incidents or filter by worker_id
 */
export async function getIncidents(workerId = null) {
  if (isConfigured && supabase) {
    try {
      let query = supabase.from('incidents').select('*').order('created_at', { ascending: false });
      if (workerId) {
        query = query.eq('worker_id', workerId);
      }
      const { data, error } = await query;
      if (!error && data) {
        return data;
      }
      console.warn('Supabase getIncidents error, falling back to local store:', error);
    } catch (err) {
      console.warn('Supabase query failed:', err);
    }
  }

  // Fallback to local storage
  const localIncidents = LocalStorage.getIncidents();
  if (workerId) {
    return localIncidents.filter(inc => inc.worker_id === workerId);
  }
  return localIncidents;
}

/**
 * Create a new incident in persistent storage
 */
export async function createIncident(incidentData) {
  const newIncident = {
    id: incidentData.id || `inc-${Date.now()}`,
    work_order_id: incidentData.work_order_id || `WO-${Math.floor(1000 + Math.random() * 9000)}`,
    worker_id: incidentData.worker_id,
    worker_name: incidentData.worker_name,
    incident_type: incidentData.incident_type,
    location: incidentData.location,
    impact: incidentData.impact,
    urgency: incidentData.urgency || 'Medium',
    priority: incidentData.priority || 'Medium',
    responsible_team: incidentData.responsible_team || null,
    status: incidentData.status || 'Submitted',
    report_mode: incidentData.report_mode || 'text',
    approval_required: incidentData.approval_required || false,
    approval_status: incidentData.approval_status || 'Not Required',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    resolved_at: null,
    events: incidentData.events || [
      {
        time: new Date().toISOString(),
        title: 'Incident Reported',
        desc: `Reported via FieldOps ${incidentData.report_mode || 'text'} mode by ${incidentData.worker_name}`,
        role: 'worker'
      }
    ]
  };

  if (isConfigured && supabase) {
    try {
      // Remove local-only properties before sending to table
      const { events, ...dbPayload } = newIncident;
      const { data, error } = await supabase.from('incidents').insert([dbPayload]).select().single();
      if (!error && data) {
        return { ...data, events };
      }
      console.warn('Failed to insert into Supabase incidents table:', error);
    } catch (err) {
      console.warn('Supabase insert exception:', err);
    }
  }

  // Local persistence
  const incidents = LocalStorage.getIncidents();
  const updated = [newIncident, ...incidents];
  LocalStorage.saveIncidents(updated);
  return newIncident;
}

/**
 * Update an existing incident (e.g. status, team, events)
 */
export async function updateIncident(incidentId, updates) {
  if (isConfigured && supabase) {
    try {
      const { events, ...dbUpdates } = updates;
      const { data, error } = await supabase
        .from('incidents')
        .update({ ...dbUpdates, updated_at: new Date().toISOString() })
        .eq('id', incidentId)
        .select()
        .single();
      if (!error && data) {
        return { ...data, events: updates.events };
      }
    } catch (err) {
      console.warn('Supabase update failed:', err);
    }
  }

  // Local persistence update
  const incidents = LocalStorage.getIncidents();
  const index = incidents.findIndex(inc => inc.id === incidentId);
  if (index !== -1) {
    incidents[index] = {
      ...incidents[index],
      ...updates,
      updated_at: new Date().toISOString()
    };
    LocalStorage.saveIncidents(incidents);
    return incidents[index];
  }
  return null;
}

/**
 * Subscribe to realtime incident events
 */
export function subscribeToIncidents(onUpdate) {
  if (!isConfigured || !supabase) {
    // Return empty unsubscribe function when offline
    return () => {};
  }

  const channel = supabase
    .channel('public:incidents')
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'incidents' },
      payload => {
        onUpdate(payload);
      }
    )
    .subscribe();

  return () => {
    supabase.removeChannel(channel);
  };
}
