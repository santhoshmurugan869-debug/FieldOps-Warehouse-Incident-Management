// ====================================================================
// FIELDOPS - RESILIENT STORAGE & LOCAL STATE ENGINE
// Zero hardcoded/fake users - Clean production storage
// ====================================================================

const STORAGE_KEYS = {
  CURRENT_WORKER: 'fieldops_current_worker',
  REGISTERED_WORKERS: 'fieldops_registered_workers',
  INCIDENTS: 'fieldops_incidents',
  NOTIFICATIONS: 'fieldops_notifications'
};

export const LocalStorage = {
  // Current active worker session
  getCurrentWorker() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CURRENT_WORKER);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  },

  setCurrentWorker(worker) {
    try {
      if (!worker) {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_WORKER);
      } else {
        localStorage.setItem(STORAGE_KEYS.CURRENT_WORKER, JSON.stringify(worker));
      }
    } catch (e) {
      console.error('Failed to save current worker', e);
    }
  },

  // Registered workers database
  getRegisteredWorkers() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.REGISTERED_WORKERS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveRegisteredWorkers(workers) {
    try {
      localStorage.setItem(STORAGE_KEYS.REGISTERED_WORKERS, JSON.stringify(workers));
    } catch (e) {
      console.error('Failed to save registered workers', e);
    }
  },

  addRegisteredWorker(worker) {
    const list = this.getRegisteredWorkers();
    // Check if worker already exists by worker_id (case-insensitive)
    const exists = list.some(
      w => w.worker_id?.toLowerCase() === worker.worker_id?.toLowerCase()
    );
    if (exists) {
      throw new Error(`Worker ID "${worker.worker_id}" is already registered. Please login or use a different Worker ID.`);
    }
    const updated = [...list, worker];
    this.saveRegisteredWorkers(updated);
    return worker;
  },

  findWorkerByIdAndName(workerId, name) {
    const list = this.getRegisteredWorkers();
    const cleanId = (workerId || '').trim().toLowerCase();
    const cleanName = (name || '').trim().toLowerCase();

    return list.find(w => {
      const matchId = (w.worker_id || '').trim().toLowerCase() === cleanId;
      const matchName = (w.full_name || '').trim().toLowerCase() === cleanName;
      return matchId && matchName;
    }) || null;
  },

  // Incidents
  getIncidents() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.INCIDENTS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveIncidents(incidents) {
    try {
      localStorage.setItem(STORAGE_KEYS.INCIDENTS, JSON.stringify(incidents));
    } catch (e) {
      console.error('Failed to save incidents locally', e);
    }
  },

  // Notifications
  getNotifications() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveNotifications(notifications) {
    try {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifications));
    } catch (e) {
      console.error('Failed to save notifications locally', e);
    }
  }
};
