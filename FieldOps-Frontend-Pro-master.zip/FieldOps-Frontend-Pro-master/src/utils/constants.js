// ====================================================================
// FIELDOPS - SYSTEM CONSTANTS & WORKFLOW RULES
// ====================================================================

export const INCIDENT_TYPES = [
  'Damaged Pallet',
  'Short Shipment',
  'Temperature Breach',
  'Machine Down'
];

export const TEAM_MAPPINGS = {
  'Damaged Pallet': 'Warehouse Handling Team',
  'Short Shipment': 'Inventory / Dispatch Team',
  'Temperature Breach': 'Cold Chain Team',
  'Machine Down': 'Maintenance Team'
};

export const TEAM_DETAILS = {
  'Warehouse Handling Team': {
    lead: 'Vikram Singh',
    contact: 'Ext. 401 / Radio Ch. 2',
    color: 'emerald',
    icon: 'Package'
  },
  'Inventory / Dispatch Team': {
    lead: 'Priya Sharma',
    contact: 'Ext. 405 / Radio Ch. 4',
    color: 'blue',
    icon: 'Truck'
  },
  'Cold Chain Team': {
    lead: 'Marcus Vance',
    contact: 'Ext. 410 / Radio Ch. 6',
    color: 'cyan',
    icon: 'ThermometerSnowflake'
  },
  'Maintenance Team': {
    lead: 'Dave K.',
    contact: 'Ext. 499 / Radio Ch. 9 (Urgent)',
    color: 'amber',
    icon: 'Wrench'
  }
};

export const URGENCY_LEVELS = {
  Low: {
    label: 'Low',
    description: 'Minor operational issue.',
    badgeClass: 'bg-slate-100 text-slate-700 border-slate-200',
    requiresApproval: false
  },
  Medium: {
    label: 'Medium',
    description: 'Limited operational impact.',
    badgeClass: 'bg-amber-50 text-amber-800 border-amber-200',
    requiresApproval: false
  },
  High: {
    label: 'High',
    description: 'Significant operational disruption, major shipment/dispatch delay, many orders affected, immediate team intervention required.',
    badgeClass: 'bg-orange-50 text-orange-800 border-orange-200',
    requiresApproval: true
  },
  Critical: {
    label: 'Critical',
    description: 'Immediate danger, major safety risk, fire/chemical leak, severe temperature breach, complete shutdown of critical operation.',
    badgeClass: 'bg-red-50 text-red-800 border-red-200 animate-pulse-slow',
    requiresApproval: true
  }
};

export const INCIDENT_STATUSES = {
  Submitted: {
    label: 'Submitted',
    color: 'slate',
    step: 1
  },
  Processing: {
    label: 'Processing',
    color: 'blue',
    step: 2
  },
  'Awaiting Supervisor Approval': {
    label: 'Awaiting Supervisor Approval',
    color: 'amber',
    step: 3
  },
  Approved: {
    label: 'Approved',
    color: 'emerald',
    step: 4
  },
  'Supervisor Rejected': {
    label: 'Supervisor Rejected (Continuing Resolution)',
    color: 'orange',
    step: 4
  },
  Assigned: {
    label: 'Assigned',
    color: 'indigo',
    step: 5
  },
  'In Progress': {
    label: 'In Progress',
    color: 'blue',
    step: 6
  },
  Resolved: {
    label: 'Resolved',
    color: 'emerald',
    step: 7
  },
  Closed: {
    label: 'Closed',
    color: 'slate',
    step: 8
  }
};

export const TEAM_UPDATE_STAGES = [
  'Team Assigned',
  'Team Acknowledged',
  'Team On The Way',
  'Work Started',
  'Work Completed',
  'Incident Resolved'
];

export const WAREHOUSE_LOCATIONS = [
  'Packing Area - Line 1',
  'Packing Area - Line 2',
  'Cold Storage Bay 4',
  'Deep Freeze Section A',
  'Inbound Loading Dock 2',
  'Outbound Dispatch Bay 5',
  'Aisle 12B - High Rack Storage',
  'Pallet Staging Area C',
  'Conveyor Belt Hub 3'
];
