// ====================================================================
// FIELDOPS - MAIN APPLICATION ROOT COMPONENT
// ====================================================================

import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { IncidentProvider } from './context/IncidentContext';
import AppLayout from './layouts/AppLayout';

import Dashboard from './pages/Dashboard';
import ReportIncident from './pages/ReportIncident';
import MyIncidents from './pages/MyIncidents';
import IncidentDetails from './pages/IncidentDetails';
import WorkerProfile from './pages/WorkerProfile';
import Notifications from './pages/Notifications';
import SopGuidelines from './pages/SopGuidelines';
import Login from './pages/Login';
import Register from './pages/Register';

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [currentTab, setCurrentTab] = useState('dashboard');
  const [selectedIncidentId, setSelectedIncidentId] = useState(null);
  const [authView, setAuthView] = useState('login'); // 'login' | 'register'

  // If worker is not logged in
  if (!isAuthenticated) {
    if (authView === 'register') {
      return (
        <Register
          onGoToLogin={() => setAuthView('login')}
          onRegisterSuccess={() => setCurrentTab('dashboard')}
        />
      );
    }
    return (
      <Login
        onGoToRegister={() => setAuthView('register')}
        onLoginSuccess={() => setCurrentTab('dashboard')}
      />
    );
  }

  const handleSelectIncident = (id) => {
    setSelectedIncidentId(id);
    setCurrentTab('incident-detail');
  };

  const handleIncidentCreated = (id) => {
    setSelectedIncidentId(id);
    setCurrentTab('incident-detail');
  };

  return (
    <AppLayout currentTab={currentTab} setTab={setCurrentTab}>
      {currentTab === 'dashboard' && (
        <Dashboard
          onNavigate={(tab) => setCurrentTab(tab)}
          onSelectIncident={handleSelectIncident}
        />
      )}

      {currentTab === 'report' && (
        <ReportIncident
          onIncidentCreated={handleIncidentCreated}
        />
      )}

      {currentTab === 'incidents' && (
        <MyIncidents
          onSelectIncident={handleSelectIncident}
          onNewIncident={() => setCurrentTab('report')}
        />
      )}

      {currentTab === 'incident-detail' && (
        <IncidentDetails
          incidentId={selectedIncidentId}
          onBack={() => setCurrentTab('dashboard')}
        />
      )}

      {currentTab === 'profile' && (
        <WorkerProfile />
      )}

      {currentTab === 'notifications' && (
        <Notifications
          onSelectIncident={handleSelectIncident}
        />
      )}

      {currentTab === 'sop' && (
        <SopGuidelines />
      )}
    </AppLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <IncidentProvider>
        <AppContent />
      </IncidentProvider>
    </AuthProvider>
  );
}
