// ====================================================================
// FIELDOPS - LOADING & ERROR STATE COMPONENTS
// ====================================================================

import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

export function LoadingState({ message = 'Loading warehouse operations...' }) {
  return (
    <div className="py-16 text-center flex flex-col items-center justify-center">
      <div className="w-9 h-9 border-3 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mb-3" />
      <p className="text-xs font-medium text-slate-500">{message}</p>
    </div>
  );
}

export function ErrorState({ title = 'Error', message = 'Something went wrong.', onRetry }) {
  return (
    <div className="warehouse-card p-8 text-center flex flex-col items-center justify-center border-red-200 bg-red-50/30">
      <div className="w-10 h-10 rounded-xl bg-red-100 flex items-center justify-center text-red-600 mb-2.5">
        <AlertTriangle className="w-5 h-5" />
      </div>
      <h4 className="text-sm font-semibold text-slate-900">{title}</h4>
      <p className="text-xs text-slate-500 max-w-sm mt-1 mb-4">{message}</p>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-white border border-slate-300 text-xs font-medium text-slate-700 hover:bg-slate-50 shadow-2xs transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Retry</span>
        </button>
      )}
    </div>
  );
}
