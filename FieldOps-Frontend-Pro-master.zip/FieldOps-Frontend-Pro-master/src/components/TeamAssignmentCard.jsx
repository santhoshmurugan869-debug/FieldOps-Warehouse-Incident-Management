// ====================================================================
// FIELDOPS - TEAM ASSIGNMENT CARD COMPONENT
// ====================================================================

import React from 'react';
import { 
  Wrench, 
  Package, 
  Truck, 
  ThermometerSnowflake, 
  Radio, 
  UserCheck, 
  ShieldCheck,
  PhoneCall
} from 'lucide-react';
import { TEAM_DETAILS } from '../utils/constants';

const ICON_MAP = {
  Package: Package,
  Truck: Truck,
  ThermometerSnowflake: ThermometerSnowflake,
  Wrench: Wrench
};

export default function TeamAssignmentCard({ teamName, status, compact = false }) {
  if (!teamName) {
    return (
      <div className="p-4 rounded-xl border border-dashed border-slate-300 bg-slate-50/70 text-center">
        <p className="text-xs text-slate-500 font-medium">Pending team dispatch by AI coordinator...</p>
      </div>
    );
  }

  const team = TEAM_DETAILS[teamName] || {
    lead: 'Duty Specialist',
    contact: 'Radio Ch. 1',
    color: 'slate',
    icon: 'Wrench'
  };

  const Icon = ICON_MAP[team.icon] || Wrench;

  if (compact) {
    return (
      <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-slate-100/90 border border-slate-200">
        <div className="p-1.5 rounded-md bg-white border border-slate-200 text-slate-700 shadow-2xs">
          <Icon className="w-4 h-4 text-blue-600" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-semibold text-slate-900 truncate">{teamName}</p>
          <p className="text-[11px] text-slate-500 flex items-center gap-1">
            <Radio className="w-3 h-3 text-slate-400" />
            <span>{team.contact}</span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm hover:border-slate-300 transition-all">
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-blue-50 border border-blue-200/60 text-blue-700">
            <Icon className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-bold tracking-wider text-blue-700 uppercase bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              Assigned Response Team
            </span>
            <h4 className="text-base font-semibold text-slate-900 mt-1">{teamName}</h4>
          </div>
        </div>
        <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Active Dispatch</span>
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-100 text-xs">
        <div className="flex items-center gap-2 text-slate-600">
          <UserCheck className="w-4 h-4 text-slate-400 shrink-0" />
          <div>
            <p className="text-[11px] text-slate-400">Team Lead</p>
            <p className="font-medium text-slate-800">{team.lead}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-slate-600">
          <PhoneCall className="w-4 h-4 text-slate-400 shrink-0" />
          <div>
            <p className="text-[11px] text-slate-400">Floor Comms</p>
            <p className="font-medium text-slate-800">{team.contact}</p>
          </div>
        </div>
      </div>

      {status && (
        <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-xs">
          <span className="text-slate-500">Live Operation Status:</span>
          <span className="font-medium text-blue-700 bg-blue-50/80 px-2 py-0.5 rounded border border-blue-100">
            {status}
          </span>
        </div>
      )}
    </div>
  );
}
