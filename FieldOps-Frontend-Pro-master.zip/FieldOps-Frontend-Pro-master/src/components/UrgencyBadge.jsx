// ====================================================================
// FIELDOPS - URGENCY BADGE COMPONENT
// ====================================================================

import React from 'react';
import { AlertTriangle, AlertOctagon, Info, ShieldAlert } from 'lucide-react';

const URGENCY_CONFIG = {
  Low: {
    bg: 'bg-slate-50',
    text: 'text-slate-700',
    border: 'border-slate-200',
    icon: Info
  },
  Medium: {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-200',
    icon: AlertTriangle
  },
  High: {
    bg: 'bg-orange-50',
    text: 'text-orange-800',
    border: 'border-orange-200',
    icon: AlertTriangle
  },
  Critical: {
    bg: 'bg-rose-50',
    text: 'text-rose-800',
    border: 'border-rose-200',
    icon: ShieldAlert
  }
};

export default function UrgencyBadge({ urgency = 'Medium', size = 'md', showLabel = true }) {
  const config = URGENCY_CONFIG[urgency] || URGENCY_CONFIG['Medium'];
  const Icon = config.icon;

  const sizeClasses = size === 'sm'
    ? 'px-2 py-0.5 text-xs gap-1'
    : size === 'lg'
    ? 'px-3 py-1.5 text-sm gap-2 font-semibold'
    : 'px-2.5 py-1 text-xs gap-1.5 font-medium';

  return (
    <span
      className={`inline-flex items-center rounded-md border ${config.bg} ${config.text} ${config.border} ${sizeClasses}`}
      title={`Urgency: ${urgency}`}
    >
      <Icon className={size === 'lg' ? 'w-4 h-4' : 'w-3.5 h-3.5'} />
      {showLabel && <span>{urgency.toUpperCase()}</span>}
    </span>
  );
}
