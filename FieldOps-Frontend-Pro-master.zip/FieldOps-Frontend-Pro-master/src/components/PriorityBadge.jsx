// ====================================================================
// FIELDOPS - PRIORITY BADGE COMPONENT
// ====================================================================

import React from 'react';
import { ArrowUp, ArrowRight, ArrowDown } from 'lucide-react';

export default function PriorityBadge({ priority = 'Medium', size = 'sm' }) {
  const isHigh = priority?.toLowerCase() === 'high';
  const isLow = priority?.toLowerCase() === 'low';

  const styles = isHigh
    ? 'bg-red-50 text-red-700 border-red-200'
    : isLow
    ? 'bg-slate-100 text-slate-600 border-slate-200'
    : 'bg-blue-50 text-blue-700 border-blue-200';

  const Icon = isHigh ? ArrowUp : isLow ? ArrowDown : ArrowRight;

  return (
    <span
      className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 text-[11px] font-medium uppercase tracking-wider ${styles}`}
    >
      <Icon className="w-3 h-3" />
      <span>Pri: {priority}</span>
    </span>
  );
}
