// ====================================================================
// FIELDOPS - VOICE REPORT RECORDER COMPONENT
// Mobile-friendly, one-handed warehouse operation
// ====================================================================

import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  Square, 
  Play, 
  Pause, 
  RotateCcw, 
  Send, 
  AlertCircle, 
  CheckCircle2,
  Volume2
} from 'lucide-react';
import { AudioRecorder } from '../services/audioService';

export default function VoiceReportButton({ onSubmit, isSubmitting = false }) {
  const [recorderStatus, setRecorderStatus] = useState('idle'); // idle, listening, recording, review, submitted
  const [recordDuration, setRecordDuration] = useState(0);
  const [audioResult, setAudioResult] = useState(null);
  const [volumeLevel, setVolumeLevel] = useState(0);
  const [isPlayingPreview, setIsPlayingPreview] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);

  const recorderRef = useRef(null);
  const timerRef = useRef(null);
  const audioPreviewRef = useRef(null);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (recorderRef.current) recorderRef.current.cleanup();
    };
  }, []);

  const startRecording = async () => {
    setErrorMessage(null);
    setAudioResult(null);
    setRecordDuration(0);
    setRecorderStatus('listening');

    try {
      const recorder = new AudioRecorder();
      recorderRef.current = recorder;

      await recorder.start((vol) => {
        setVolumeLevel(vol);
      });

      setRecorderStatus('recording');

      // Start duration counter
      timerRef.current = setInterval(() => {
        setRecordDuration(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Failed to start recording:', err);
      setRecorderStatus('idle');
      setErrorMessage(
        err.name === 'NotAllowedError'
          ? 'Microphone permission denied. Please allow microphone access in your browser.'
          : 'Unable to initialize microphone. Please check your audio settings.'
      );
    }
  };

  const stopRecording = async () => {
    if (timerRef.current) clearInterval(timerRef.current);

    if (recorderRef.current) {
      try {
        const result = await recorderRef.current.stop();
        setAudioResult(result);
        setRecorderStatus('review');
      } catch (err) {
        console.error('Error stopping recording:', err);
        setRecorderStatus('idle');
        setErrorMessage('Failed to capture audio. Please try again.');
      }
    }
  };

  const handleReset = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (audioPreviewRef.current) {
      audioPreviewRef.current.pause();
    }
    setRecorderStatus('idle');
    setRecordDuration(0);
    setAudioResult(null);
    setVolumeLevel(0);
    setIsPlayingPreview(false);
  };

  const togglePlayPreview = () => {
    if (!audioPreviewRef.current) return;
    if (isPlayingPreview) {
      audioPreviewRef.current.pause();
      setIsPlayingPreview(false);
    } else {
      audioPreviewRef.current.play();
      setIsPlayingPreview(true);
    }
  };

  const handleSubmit = async () => {
    if (!audioResult?.blob) return;
    try {
      setRecorderStatus('submitting');
      await onSubmit(audioResult.blob);
      setRecorderStatus('submitted');
    } catch (err) {
      setRecorderStatus('review');
      setErrorMessage(err.message || 'Failed to submit voice report.');
    }
  };

  const formatTimer = (secs) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="flex flex-col items-center justify-center p-6 sm:p-8 bg-slate-50 rounded-2xl border border-slate-200 text-center">
      {/* Error alert if any */}
      {errorMessage && (
        <div className="w-full mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 flex items-start gap-2 text-left">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Main Microphone Button */}
      {recorderStatus === 'idle' && (
        <div className="flex flex-col items-center">
          <button
            type="button"
            onClick={startRecording}
            className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white flex items-center justify-center shadow-lg shadow-blue-500/20 transition-all focus:outline-none focus:ring-4 focus:ring-blue-100"
            aria-label="Start Voice Incident Recording"
          >
            <Mic className="w-10 h-10 sm:w-12 sm:h-12" />
          </button>
          <h4 className="text-base font-semibold text-slate-800 mt-4">Tap to Speak</h4>
          <p className="text-xs text-slate-500 max-w-xs mt-1">
            State the issue clearly. Example: <span className="italic font-medium text-slate-700">"Machine Down at Packing Area Line 1, hydraulic pressure failure."</span>
          </p>
        </div>
      )}

      {/* Listening / Recording Active State */}
      {(recorderStatus === 'listening' || recorderStatus === 'recording') && (
        <div className="flex flex-col items-center">
          <div className="relative">
            {/* Pulsing ring proportional to audio volume */}
            <div
              className="absolute inset-0 rounded-full bg-red-500/20 animate-ping"
              style={{ transform: `scale(${1 + volumeLevel / 100})` }}
            />
            <button
              type="button"
              onClick={stopRecording}
              className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-red-600 hover:bg-red-700 text-white flex flex-col items-center justify-center shadow-xl shadow-red-500/30 transition-all active:scale-95"
              aria-label="Stop Recording"
            >
              <Square className="w-8 h-8 fill-current" />
              <span className="text-[11px] font-bold uppercase tracking-wider mt-1">Stop</span>
            </button>
          </div>

          <div className="mt-4 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-pulse" />
            <span className="text-sm font-mono font-bold text-red-700">
              {formatTimer(recordDuration)}
            </span>
          </div>

          <p className="text-xs font-semibold text-slate-700 mt-1 uppercase tracking-wider">
            {recorderStatus === 'listening' ? 'Listening...' : 'Recording Audio...'}
          </p>

          <p className="text-xs text-slate-400 mt-1">Tap Stop when finished speaking</p>
        </div>
      )}

      {/* Review Audio State */}
      {(recorderStatus === 'review' || recorderStatus === 'submitting') && (
        <div className="w-full max-w-md flex flex-col items-center">
          <div className="w-full bg-white p-4 rounded-xl border border-slate-200 shadow-2xs mb-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={togglePlayPreview}
                  className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center shadow-xs"
                >
                  {isPlayingPreview ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                </button>
                <div className="text-left">
                  <p className="text-xs font-semibold text-slate-800">Voice Note Recorded</p>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Duration: {formatTimer(audioResult?.duration || 0)}
                  </p>
                </div>
              </div>

              {audioResult?.url && (
                <audio
                  ref={audioPreviewRef}
                  src={audioResult.url}
                  onEnded={() => setIsPlayingPreview(false)}
                  className="hidden"
                />
              )}

              <button
                type="button"
                onClick={handleReset}
                disabled={recorderStatus === 'submitting'}
                className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 p-2 rounded-lg hover:bg-slate-100"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retake</span>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full">
            <button
              type="button"
              onClick={handleReset}
              disabled={recorderStatus === 'submitting'}
              className="flex-1 py-3 px-4 rounded-xl border border-slate-300 text-slate-700 font-medium text-sm hover:bg-slate-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSubmit}
              disabled={recorderStatus === 'submitting' || isSubmitting}
              className="flex-2 py-3 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium text-sm shadow-sm flex items-center justify-center gap-2 disabled:opacity-50 transition-colors"
            >
              {recorderStatus === 'submitting' || isSubmitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Submitting to AI...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Submit Voice Report</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Submitted State */}
      {recorderStatus === 'submitted' && (
        <div className="flex flex-col items-center py-4 text-emerald-600">
          <CheckCircle2 className="w-12 h-12 mb-2" />
          <h4 className="text-base font-semibold text-slate-900">Voice Report Submitted!</h4>
          <p className="text-xs text-slate-500 mt-1">AI agent is transcribing and categorizing your report.</p>
          <button
            type="button"
            onClick={handleReset}
            className="mt-4 text-xs font-medium text-blue-600 hover:underline"
          >
            Record another voice incident
          </button>
        </div>
      )}
    </div>
  );
}
