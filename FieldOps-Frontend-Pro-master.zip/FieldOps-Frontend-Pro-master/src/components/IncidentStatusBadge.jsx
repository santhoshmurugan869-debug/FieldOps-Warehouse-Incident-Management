// ====================================================================
// FIELDOPS - INCIDENT STATUS BADGE COMPONENT
// ====================================================================

import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  ArrowUpRight, 
  Users, 
  XCircle, 
  Send,
  Cpu
} from 'lucide-react';

const STATUS_CONFIGS = {
  Submitted: {
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    border: 'border-slate-300',
    dot: 'bg-slate-500',
    icon: Send
  },
  Processing: {
    bg: 'bg-blue-50',
    text: 'text-blue-700',
    border: 'border-blue-200',
    dot: 'bg-blue-500 animate-ping',
    icon: Cpu
  },
  'Awaiting Supervisor Approval': {
    bg: 'bg-amber-50',
    text: 'text-amber-800',
    border: 'border-amber-300',
    dot: 'bg-amber-500 animate-pulse',
    icon: Clock
  },
  Approved: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-300',
    dot: 'bg-emerald-500',
    icon: CheckCircle2
  },
  'Supervisor Rejected': {
    bg: 'bg-orange-50',
    text: 'text-orange-800',
    border: 'border-orange-300',
    dot: 'bg-orange-500',
    icon: AlertCircle
  },
  Assigned: {
    bg: 'bg-indigo-50',
    text: 'text-indigo-700',
    border: 'border-indigo-200',
    dot: 'bg-indigo-500',
    icon: Users
  },
  'In Progress': {
    bg: 'bg-sky-50',
    text: 'text-sky-700',
    border: 'border-sky-300',
    dot: 'bg-sky-500 animate-pulse',
    icon: ArrowUpRight
  },
  Resolved: {
    bg: 'bg-emerald-50',
    text: 'text-emerald-700',
    border: 'border-emerald-300',
    dot: 'bg-emerald-600',
    icon: CheckCircle2
  },
  Closed: {
    bg: 'bg-slate-100',
    text: 'text-slate-600',
    border: 'border-slate-200',
    dot: 'bg-slate-400',
    icon: XCircle
  }
};

export default function IncidentStatusBadge({ status, size = 'md' }) {
  const config = STATUS_CONFIGS[status] || STATUS_CONFIGS['Submitted'];
  const Icon = config.icon;

  const sizeClasses = size === 'sm'
    ? 'px-2 py-0.5 text-xs gap-1.5'
    : size === 'lg'
    ? 'px-3.5 py-1.5 text-sm gap-2 font-medium'
    : 'px-2.5 py-1 text-xs gap-1.5 font-medium';

  return (
    <span
      className={`inline-flex items-center rounded-full border ${config.bg} ${config.text} ${config.border} ${sizeClasses}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${config.dot}`} />
      <Icon className={size === 'lg' ? 'w-4 h-4' : 'w-3.5 h-3.5'} />
      <span>{status}</span>
    </span>
  );
}
