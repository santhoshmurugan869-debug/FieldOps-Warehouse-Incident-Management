// ====================================================================
// FIELDOPS - STATS CARD COMPONENT
// ====================================================================

import React from 'react';

export default function StatsCard({ label, value, icon: Icon, color = 'blue', subtext, onClick }) {
  const colorStyles = {
    blue: 'text-blue-600 bg-blue-50 border-blue-100',
    amber: 'text-amber-600 bg-amber-50 border-amber-100',
    indigo: 'text-indigo-600 bg-indigo-50 border-indigo-100',
    emerald: 'text-emerald-600 bg-emerald-50 border-emerald-100',
    rose: 'text-rose-600 bg-rose-50 border-rose-100',
    slate: 'text-slate-600 bg-slate-100 border-slate-200'
  }[color] || 'text-blue-600 bg-blue-50 border-blue-100';

  return (
    <div
      onClick={onClick}
      className={`warehouse-card p-4 flex flex-col justify-between ${
        onClick ? 'cursor-pointer hover:border-slate-300' : ''
      }`}
    >
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-xs font-medium text-slate-500 truncate">{label}</span>
        {Icon && (
          <div className={`p-2 rounded-lg border ${colorStyles}`}>
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-bold tracking-tight text-slate-900 font-mono">
          {value ?? 0}
        </span>
      </div>

      {subtext && (
        <p className="text-[11px] text-slate-400 mt-1.5 flex items-center gap-1">
          {subtext}
        </p>
      )}
    </div>
  );
}
