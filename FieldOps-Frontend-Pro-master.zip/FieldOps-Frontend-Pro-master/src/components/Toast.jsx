// ====================================================================
// FIELDOPS - TOAST NOTIFICATION CONTAINER
// ====================================================================

import React from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { useIncidents } from '../context/IncidentContext';

export default function ToastContainer() {
  const { toasts, removeToast } = useIncidents();

  if (!toasts || toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none px-3">
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        const isError = toast.type === 'error';

        const borderStyle = isSuccess 
          ? 'border-emerald-300 bg-emerald-50 text-emerald-900' 
          : isError 
          ? 'border-red-300 bg-red-50 text-red-900' 
          : 'border-slate-300 bg-white text-slate-900';

        const Icon = isSuccess ? CheckCircle2 : isError ? AlertCircle : Info;
        const iconColor = isSuccess ? 'text-emerald-600' : isError ? 'text-red-600' : 'text-blue-600';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-3.5 rounded-xl border shadow-lg transition-all animate-in slide-in-from-bottom-2 ${borderStyle}`}
          >
            <Icon className={`w-5 h-5 shrink-0 mt-0.5 ${iconColor}`} />
            <div className="flex-1 min-w-0">
              <h5 className="text-xs font-semibold">{toast.title}</h5>
              <p className="text-xs opacity-90 mt-0.5 leading-relaxed">{toast.message}</p>
            </div>
            <button
              onClick={() => removeToast(toast.id)}
              className="p-1 rounded-md opacity-60 hover:opacity-100 hover:bg-black/5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
