// ====================================================================
// FIELDOPS - WORKER AVATAR COMPONENT
// ====================================================================

import React from 'react';

export default function WorkerAvatar({ name = 'Worker', id = '', size = 'md' }) {
  const getInitials = (n) => {
    if (!n) return 'W';
    const parts = n.trim().split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return n.slice(0, 2).toUpperCase();
  };

  const sizeClasses = size === 'sm'
    ? 'w-7 h-7 text-xs'
    : size === 'lg'
    ? 'w-12 h-12 text-base font-semibold'
    : size === 'xl'
    ? 'w-16 h-16 text-xl font-bold'
    : 'w-9 h-9 text-sm font-medium';

  return (
    <div
      className={`inline-flex items-center justify-center rounded-full bg-slate-800 text-white font-mono tracking-tight shadow-sm select-none shrink-0 ${sizeClasses}`}
      title={`${name} (${id})`}
    >
      {getInitials(name)}
    </div>
  );
}
