// ====================================================================
// FIELDOPS - INCIDENT CARD COMPONENT
// ====================================================================

import React from 'react';
import { 
  MapPin, 
  Clock, 
  FileText, 
  ArrowRight, 
  Mic, 
  User, 
  AlertCircle 
} from 'lucide-react';
import IncidentStatusBadge from './IncidentStatusBadge';
import UrgencyBadge from './UrgencyBadge';
import PriorityBadge from './PriorityBadge';
import TeamAssignmentCard from './TeamAssignmentCard';
import { formatTime, timeAgo } from '../utils/dateUtils';

export default function IncidentCard({ incident, onViewDetails, onSelect }) {
  if (!incident) return null;

  return (
    <div
      onClick={() => onSelect ? onSelect(incident.id) : onViewDetails ? onViewDetails(incident) : null}
      className="warehouse-card warehouse-card-hover p-4 sm:p-5 flex flex-col justify-between cursor-pointer group"
    >
      {/* Top row: Work Order & Status */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
              {incident.work_order_id || 'WO-PENDING'}
            </span>
            {incident.report_mode === 'voice' && (
              <span className="inline-flex items-center gap-1 text-[11px] text-purple-700 bg-purple-50 border border-purple-200 px-1.5 py-0.5 rounded" title="Voice Reported">
                <Mic className="w-3 h-3" />
                <span className="hidden sm:inline">Voice</span>
              </span>
            )}
          </div>
          <IncidentStatusBadge status={incident.status} size="sm" />
        </div>

        {/* Title & Location */}
        <h3 className="text-base font-semibold text-slate-900 group-hover:text-blue-600 transition-colors flex items-center justify-between">
          <span>{incident.incident_type}</span>
          <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-all" />
        </h3>

        <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="truncate">{incident.location}</span>
        </div>

        {/* Impact description snippet */}
        {incident.impact && (
          <p className="text-xs text-slate-600 mt-2 line-clamp-2 leading-relaxed bg-slate-50/60 p-2 rounded border border-slate-100">
            {incident.impact}
          </p>
        )}

        {/* Badges: Urgency & Priority */}
        <div className="flex flex-wrap items-center gap-2 mt-3 pt-2.5 border-t border-slate-100">
          <UrgencyBadge urgency={incident.urgency} size="sm" />
          <PriorityBadge priority={incident.priority} size="sm" />
          {incident.approval_required && (
            <span className={`text-[11px] px-2 py-0.5 rounded border font-medium ${
              incident.approval_status === 'Approved'
                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                : incident.approval_status === 'Pending'
                ? 'bg-amber-50 text-amber-800 border-amber-200'
                : 'bg-slate-100 text-slate-600 border-slate-200'
            }`}>
              Supervisor: {incident.approval_status || 'Required'}
            </span>
          )}
        </div>
      </div>

      {/* Bottom section: Team & Reported Time */}
      <div className="mt-4 pt-3 border-t border-slate-100">
        <TeamAssignmentCard teamName={incident.responsible_team} compact={true} />

        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2.5">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{timeAgo(incident.created_at)}</span>
          </span>
          <span className="truncate max-w-[120px] text-right font-medium text-slate-500">
            {incident.worker_name || incident.worker_id}
          </span>
        </div>
      </div>
    </div>
  );
}
