// ====================================================================
// FIELDOPS - STATUS PROGRESSION STEPPER COMPONENT
// ====================================================================

import React from 'react';
import { Check, Clock, AlertCircle } from 'lucide-react';

const WORKFLOW_STEPS = [
  { key: 'reported', label: 'Reported' },
  { key: 'ai_classified', label: 'AI Classified' },
  { key: 'team_assigned', label: 'Team Assigned' },
  { key: 'acknowledged', label: 'Team Acknowledged' },
  { key: 'in_progress', label: 'Work In Progress' },
  { key: 'resolved', label: 'Resolved' }
];

export default function StatusStepper({ incident, orientation = 'horizontal' }) {
  if (!incident) return null;

  const status = incident.status || 'Submitted';
  const approvalStatus = incident.approval_status;
  const events = incident.events || [];

  // Determine current active step index (0 to 5)
  let currentStep = 0;
  if (status === 'Submitted') currentStep = 0;
  else if (status === 'Processing') currentStep = 1;
  else if (status === 'Awaiting Supervisor Approval') currentStep = 1;
  else if (status === 'Approved' || status === 'Supervisor Rejected' || status === 'Assigned') currentStep = 2;
  else if (events.some(e => e.title.includes('Acknowledged'))) currentStep = 3;
  if (events.some(e => e.title.includes('On The Way'))) currentStep = 3.5;
  if (status === 'In Progress' || events.some(e => e.title.includes('Work In Progress') || e.title.includes('Work Started'))) {
    currentStep = 4;
  }
  if (status === 'Resolved' || status === 'Closed') {
    currentStep = 5;
  }

  if (orientation === 'vertical') {
    return (
      <div className="space-y-4 py-2">
        {WORKFLOW_STEPS.map((step, index) => {
          const isDone = currentStep > index;
          const isCurrent = Math.floor(currentStep) === index;
          const isPending = currentStep < index;

          return (
            <div key={step.key} className="flex items-start gap-3 relative">
              {index < WORKFLOW_STEPS.length - 1 && (
                <div
                  className={`absolute left-3.5 top-7 bottom-0 w-0.5 -mb-2 ${
                    isDone ? 'bg-blue-600' : 'bg-slate-200'
                  }`}
                />
              )}
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 z-10 text-xs font-semibold transition-all ${
                  isDone
                    ? 'bg-blue-600 text-white'
                    : isCurrent
                    ? 'bg-blue-50 border-2 border-blue-600 text-blue-700 ring-4 ring-blue-50'
                    : 'bg-slate-100 border border-slate-300 text-slate-400'
                }`}
              >
                {isDone ? <Check className="w-3.5 h-3.5" /> : isCurrent ? <Clock className="w-3.5 h-3.5 animate-spin" /> : index + 1}
              </div>
              <div className="pt-0.5 min-w-0 flex-1">
                <p
                  className={`text-sm font-medium ${
                    isDone
                      ? 'text-slate-800'
                      : isCurrent
                      ? 'text-blue-700 font-semibold'
                      : 'text-slate-400'
                  }`}
                >
                  {step.label}
                </p>
                {isCurrent && (
                  <p className="text-xs text-blue-600 mt-0.5 animate-pulse">
                    Current stage: {status}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  // Horizontal Stepper for Cards & Header
  return (
    <div className="w-full py-2">
      <div className="flex items-center justify-between relative">
        {/* Background track line */}
        <div className="absolute top-3.5 left-4 right-4 h-0.5 bg-slate-200 -z-0" />
        {/* Filled progress bar */}
        <div
          className="absolute top-3.5 left-4 h-0.5 bg-blue-600 transition-all duration-500 -z-0"
          style={{ width: `${Math.min(100, (currentStep / (WORKFLOW_STEPS.length - 1)) * 92)}%` }}
        />

        {WORKFLOW_STEPS.map((step, index) => {
          const isDone = currentStep > index;
          const isCurrent = Math.floor(currentStep) === index;
          const isPending = currentStep < index;

          return (
            <div key={step.key} className="flex flex-col items-center group relative z-10">
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                  isDone
                    ? 'bg-blue-600 text-white shadow-xs'
                    : isCurrent
                    ? 'bg-white border-2 border-blue-600 text-blue-700 ring-4 ring-blue-50 shadow-xs'
                    : 'bg-white border border-slate-300 text-slate-400'
                }`}
              >
                {isDone ? (
                  <Check className="w-3.5 h-3.5" />
                ) : isCurrent ? (
                  <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping" />
                ) : (
                  <span>{index + 1}</span>
                )}
              </div>
              <span
                className={`text-[11px] mt-1.5 font-medium text-center hidden sm:block ${
                  isDone
                    ? 'text-slate-700'
                    : isCurrent
                    ? 'text-blue-700 font-semibold'
                    : 'text-slate-400'
                }`}
              >
                {step.label}
              </span>
            </div>
          );
        })}
      </div>

      {approvalStatus === 'Rejected' && (
        <div className="mt-3 flex items-center gap-1.5 p-2 rounded-lg bg-orange-50 border border-orange-200 text-xs text-orange-800">
          <AlertCircle className="w-4 h-4 shrink-0 text-orange-600" />
          <span>Supervisor rejected critical escalation; incident continues through normal resolution.</span>
        </div>
      )}
    </div>
  );
}
