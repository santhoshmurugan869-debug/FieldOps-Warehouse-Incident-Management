// ====================================================================
// FIELDOPS - ACTIVITY TIMELINE COMPONENT
// ====================================================================

import React from 'react';
import { 
  Clock, 
  CheckCircle2, 
  Send, 
  Cpu, 
  UserCheck, 
  Users, 
  Wrench,
  AlertTriangle,
  Radio,
  FileCheck
} from 'lucide-react';
import { formatTime, timeAgo } from '../utils/dateUtils';

const ROLE_CONFIG = {
  worker: {
    icon: Send,
    bg: 'bg-blue-50 text-blue-700 border-blue-200',
    dot: 'bg-blue-500'
  },
  ai: {
    icon: Cpu,
    bg: 'bg-purple-50 text-purple-700 border-purple-200',
    dot: 'bg-purple-500'
  },
  supervisor: {
    icon: UserCheck,
    bg: 'bg-amber-50 text-amber-800 border-amber-200',
    dot: 'bg-amber-500'
  },
  team: {
    icon: Wrench,
    bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    dot: 'bg-emerald-500'
  },
  system: {
    icon: FileCheck,
    bg: 'bg-slate-100 text-slate-700 border-slate-200',
    dot: 'bg-slate-500'
  }
};

export default function ActivityTimeline({ events = [], incidentId = '' }) {
  if (!events || events.length === 0) {
    return (
      <div className="py-8 text-center text-slate-400 text-sm">
        <Clock className="w-8 h-8 mx-auto mb-2 text-slate-300" />
        No activity logged yet for this incident.
      </div>
    );
  }

  // Sort events chronologically (oldest to newest for natural progression, or reversed if requested)
  const sortedEvents = [...events].sort((a, b) => new Date(a.time) - new Date(b.time));

  return (
    <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
      {sortedEvents.map((evt, idx) => {
        const roleConf = ROLE_CONFIG[evt.role] || ROLE_CONFIG.system;
        const Icon = roleConf.icon;
        const isLatest = idx === sortedEvents.length - 1;

        return (
          <div key={idx} className="relative group">
            {/* Timeline node icon */}
            <div
              className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full border-2 border-white flex items-center justify-center shadow-xs ${
                roleConf.dot
              } ${isLatest ? 'ring-4 ring-blue-100' : ''}`}
            >
              <div className="w-1.5 h-1.5 rounded-full bg-white" />
            </div>

            {/* Event content card */}
            <div className="bg-white rounded-lg border border-slate-200/90 p-3 shadow-2xs hover:border-slate-300 transition-all">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-semibold text-slate-900">
                    {formatTime(evt.time)}
                  </span>
                  <span className={`text-[10px] uppercase font-semibold px-2 py-0.5 rounded border ${roleConf.bg}`}>
                    {evt.role || 'system'}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400">
                  {timeAgo(evt.time)}
                </span>
              </div>

              <h4 className="text-sm font-semibold text-slate-900">{evt.title}</h4>
              {evt.desc && (
                <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{evt.desc}</p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
