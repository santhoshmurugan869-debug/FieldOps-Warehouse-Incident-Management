// ====================================================================
// FIELDOPS - AUTHENTICATION & REAL WORKER CONTEXT
// No fake demo names - Real user registration and Login by Worker ID & Name
// ====================================================================

import React, { createContext, useContext, useState } from 'react';
import { LocalStorage } from '../utils/storage';
import { supabase } from '../services/supabase';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [currentWorker, setCurrentWorker] = useState(() => LocalStorage.getCurrentWorker());
  const [isAuthenticated, setIsAuthenticated] = useState(() => Boolean(LocalStorage.getCurrentWorker()));

  /**
   * Login strictly using Worker ID and Name
   */
  const login = async ({ worker_id, name }) => {
    const cleanId = (worker_id || '').trim();
    const cleanName = (name || '').trim();

    if (!cleanId || !cleanName) {
      return { success: false, message: 'Please enter both your Worker ID and Name.' };
    }

    // 1. Try Supabase workers table if configured
    if (supabase) {
      try {
        const { data, error } = await supabase
          .from('workers')
          .select('*')
          .ilike('worker_id', cleanId)
          .ilike('full_name', cleanName)
          .maybeSingle();

        if (data && !error) {
          LocalStorage.setCurrentWorker(data);
          setCurrentWorker(data);
          setIsAuthenticated(true);
          return { success: true, worker: data };
        }
      } catch (err) {
        console.warn('Supabase worker query fallback to local:', err);
      }
    }

    // 2. Check locally registered workers
    const matched = LocalStorage.findWorkerByIdAndName(cleanId, cleanName);

    if (matched) {
      LocalStorage.setCurrentWorker(matched);
      setCurrentWorker(matched);
      setIsAuthenticated(true);
      return { success: true, worker: matched };
    }

    return {
      success: false,
      message: `No worker account found for Worker ID "${cleanId}" with Name "${cleanName}". Please check your details or create a new account.`
    };
  };

  /**
   * Register a new worker profile
   */
  const register = async (workerData) => {
    const cleanId = (workerData.worker_id || '').trim().toUpperCase();
    const cleanName = (workerData.full_name || '').trim();

    if (!cleanId || !cleanName) {
      return { success: false, message: 'Worker ID and Full Name are mandatory.' };
    }

    const newWorker = {
      id: `wkr-${Date.now()}`,
      worker_id: cleanId,
      full_name: cleanName,
      email: workerData.email || `${cleanId.toLowerCase()}@fieldops.internal`,
      phone: workerData.phone || '',
      warehouse_location: workerData.warehouse_location || 'Packing Warehouse',
      department: workerData.department || 'Operations',
      role: workerData.role || 'Worker',
      created_at: new Date().toISOString(),
      joined_date: new Date().toISOString().split('T')[0]
    };

    // Save to Supabase if configured
    if (supabase) {
      try {
        const { error } = await supabase.from('workers').insert([newWorker]);
        if (error) {
          console.warn('Supabase workers insert notice:', error.message);
        }
      } catch (err) {
        console.warn('Supabase worker insert exception:', err);
      }
    }

    // Save to persistent storage
    try {
      LocalStorage.addRegisteredWorker(newWorker);
      LocalStorage.setCurrentWorker(newWorker);
      setCurrentWorker(newWorker);
      setIsAuthenticated(true);
      return { success: true, worker: newWorker };
    } catch (err) {
      return { success: false, message: err.message };
    }
  };

  /**
   * Log out active worker
   */
  const logout = () => {
    LocalStorage.setCurrentWorker(null);
    setCurrentWorker(null);
    setIsAuthenticated(false);
  };

  /**
   * Update active worker profile
   */
  const updateProfile = (updatedFields) => {
    setCurrentWorker(prev => {
      if (!prev) return null;
      const updated = { ...prev, ...updatedFields, updated_at: new Date().toISOString() };
      LocalStorage.setCurrentWorker(updated);

      // Also update in registered list
      const all = LocalStorage.getRegisteredWorkers();
      const idx = all.findIndex(w => w.worker_id?.toLowerCase() === prev.worker_id?.toLowerCase());
      if (idx !== -1) {
        all[idx] = updated;
        LocalStorage.saveRegisteredWorkers(all);
      }
      return updated;
    });
  };

  return (
    <AuthContext.Provider
      value={{
        currentWorker,
        isAuthenticated,
        login,
        register,
        logout,
        updateProfile
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
