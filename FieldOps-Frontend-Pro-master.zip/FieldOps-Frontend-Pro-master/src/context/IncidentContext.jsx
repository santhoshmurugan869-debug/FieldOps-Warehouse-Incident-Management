// ====================================================================
// FIELDOPS - INCIDENTS & REALTIME WORKFLOW CONTEXT
// ====================================================================

import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import { LocalStorage } from '../utils/storage';
import { submitTextIncident, submitVoiceIncident } from '../services/api';
import { getIncidents, createIncident, updateIncident, subscribeToIncidents } from '../services/supabase';
import { TEAM_MAPPINGS, URGENCY_LEVELS } from '../utils/constants';

const IncidentContext = createContext(null);

export function IncidentProvider({ children }) {
  const { currentWorker } = useAuth();
  const [incidents, setIncidents] = useState(() => LocalStorage.getIncidents());
  const [notifications, setNotifications] = useState(() => LocalStorage.getNotifications());
  const [activeIncidentId, setActiveIncidentId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [toasts, setToasts] = useState([]);

  // Toast notification helper
  const addToast = (title, message, type = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    setToasts(prev => [...prev, { id, title, message, type, time: new Date() }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 5000);
  };

  const removeToast = (id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  // Sync with Supabase or LocalStorage on mount
  useEffect(() => {
    async function loadData() {
      setIsLoading(true);
      try {
        const fetched = await getIncidents();
        if (fetched && fetched.length > 0) {
          setIncidents(fetched);
        }
      } catch (err) {
        console.warn('Error fetching incidents:', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();

    // Subscribe to realtime changes if Supabase connected
    const unsubscribe = subscribeToIncidents((payload) => {
      console.log('[Realtime] Incident change received:', payload);
      if (payload.eventType === 'INSERT') {
        setIncidents(prev => [payload.new, ...prev]);
        addToast('New Incident', `Incident ${payload.new.work_order_id || ''} was created.`, 'info');
      } else if (payload.eventType === 'UPDATE') {
        setIncidents(prev => prev.map(inc => inc.id === payload.new.id ? { ...inc, ...payload.new } : inc));
        addToast('Status Updated', `Incident ${payload.new.work_order_id} is now ${payload.new.status}`, 'info');
      }
    });

    return () => unsubscribe();
  }, []);

  // Save incidents locally whenever changed
  useEffect(() => {
    LocalStorage.saveIncidents(incidents);
  }, [incidents]);

  // Save notifications locally whenever changed
  useEffect(() => {
    LocalStorage.saveNotifications(notifications);
  }, [notifications]);

  // Compute operational statistics
  const openIncidents = incidents.filter(inc => inc.status !== 'Resolved' && inc.status !== 'Closed');
  const myIncidents = incidents.filter(inc => inc.worker_id === currentWorker?.worker_id);
  const myActiveIncidents = myIncidents.filter(inc => inc.status !== 'Resolved' && inc.status !== 'Closed');
  const awaitingApproval = incidents.filter(inc => inc.status === 'Awaiting Supervisor Approval');
  const assignedToTeam = incidents.filter(inc => inc.status === 'Assigned' || inc.status === 'In Progress');
  
  // Resolved today count
  const todayDateString = new Date().toISOString().split('T')[0];
  const resolvedToday = incidents.filter(inc => {
    if (inc.status !== 'Resolved') return false;
    const resolvedTime = inc.resolved_at || inc.updated_at;
    return resolvedTime && resolvedTime.startsWith(todayDateString);
  });

  // Current worker's most urgent active incident for dashboard highlight
  const activeIncident = myActiveIncidents[0] || openIncidents[0] || incidents[0] || null;

  // Add system notification
  const notifyWorker = (workerId, incidentId, title, message) => {
    const newNotif = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      worker_id: workerId,
      incident_id: incidentId,
      title,
      message,
      read: false,
      created_at: new Date().toISOString()
    };
    setNotifications(prev => [newNotif, ...prev]);
    addToast(title, message, 'info');
  };

  /**
   * Post-Assignment Lifecycle Simulation
   * Realistically transitions incident through:
   * AI Extraction -> Urgency Check -> Supervisor Approval (if High/Critical) -> Team Assigned -> Acknowledged -> On The Way -> In Progress -> Resolved
   */
  const runWorkflowLifecycle = (incidentId, incidentType, initialUrgency) => {
    const assignedTeam = TEAM_MAPPINGS[incidentType] || 'Warehouse Handling Team';
    const isCriticalOrHigh = initialUrgency === 'High' || initialUrgency === 'Critical';

    // Step 1: AI Processing (1.5s)
    setTimeout(() => {
      setIncidents(prev => prev.map(inc => {
        if (inc.id !== incidentId) return inc;
        const newEvents = [
          ...(inc.events || []),
          {
            time: new Date().toISOString(),
            title: 'AI Classified Incident',
            desc: `AI extraction confirmed: ${incidentType}. Assigned Urgency: ${initialUrgency}`,
            role: 'ai'
          }
        ];
        return {
          ...inc,
          status: isCriticalOrHigh ? 'Awaiting Supervisor Approval' : 'Assigned',
          approval_required: isCriticalOrHigh,
          approval_status: isCriticalOrHigh ? 'Pending' : 'Not Required',
          responsible_team: assignedTeam,
          events: newEvents,
          updated_at: new Date().toISOString()
        };
      }));

      if (isCriticalOrHigh) {
        notifyWorker(currentWorker?.worker_id, incidentId, 'Approval Requested', `${initialUrgency} incident requires Supervisor approval. Dispatch prompt sent to Telegram.`);
      } else {
        notifyWorker(currentWorker?.worker_id, incidentId, 'Team Assigned', `${assignedTeam} has been assigned to your ${incidentType} incident.`);
      }
    }, 2000);

    // If High/Critical, simulate Supervisor Telegram Approval at 7s
    if (isCriticalOrHigh) {
      setTimeout(() => {
        setIncidents(prev => prev.map(inc => {
          if (inc.id !== incidentId) return inc;
          const newEvents = [
            ...(inc.events || []),
            {
              time: new Date().toISOString(),
              title: 'Supervisor Approved via Telegram',
              desc: `Supervisor approved critical intervention. Routing to ${assignedTeam}.`,
              role: 'supervisor'
            },
            {
              time: new Date().toISOString(),
              title: `Assigned to ${assignedTeam}`,
              desc: `Automated dispatch sent to ${assignedTeam} lead radio channel.`,
              role: 'system'
            }
          ];
          return {
            ...inc,
            status: 'Assigned',
            approval_status: 'Approved',
            events: newEvents,
            updated_at: new Date().toISOString()
          };
        }));
        notifyWorker(currentWorker?.worker_id, incidentId, 'Supervisor Approved', `Supervisor approved ${incidentType}. ${assignedTeam} assigned.`);
      }, 7000);
    }

    // Step 3: Team Acknowledged (13s)
    setTimeout(() => {
      setIncidents(prev => prev.map(inc => {
        if (inc.id !== incidentId) return inc;
        const newEvents = [
          ...(inc.events || []),
          {
            time: new Date().toISOString(),
            title: `${assignedTeam} Acknowledged`,
            desc: 'Team duty lead acknowledged dispatch and assigned technicians.',
            role: 'team'
          }
        ];
        return {
          ...inc,
          events: newEvents,
          updated_at: new Date().toISOString()
        };
      }));
      notifyWorker(currentWorker?.worker_id, incidentId, 'Team Acknowledged', `${assignedTeam} has acknowledged your incident.`);
    }, isCriticalOrHigh ? 13000 : 7000);

    // Step 4: Team On The Way (20s)
    setTimeout(() => {
      setIncidents(prev => prev.map(inc => {
        if (inc.id !== incidentId) return inc;
        const newEvents = [
          ...(inc.events || []),
          {
            time: new Date().toISOString(),
            title: `${assignedTeam} On The Way`,
            desc: 'Technicians dispatched with tools to incident location.',
            role: 'team'
          }
        ];
        return {
          ...inc,
          events: newEvents,
          updated_at: new Date().toISOString()
        };
      }));
      notifyWorker(currentWorker?.worker_id, incidentId, 'Team On The Way', `${assignedTeam} is en route to your location.`);
    }, isCriticalOrHigh ? 20000 : 13000);

    // Step 5: Work In Progress (28s)
    setTimeout(() => {
      setIncidents(prev => prev.map(inc => {
        if (inc.id !== incidentId) return inc;
        const newEvents = [
          ...(inc.events || []),
          {
            time: new Date().toISOString(),
            title: 'Work In Progress',
            desc: `${assignedTeam} has begun active remediation on site.`,
            role: 'team'
          }
        ];
        return {
          ...inc,
          status: 'In Progress',
          events: newEvents,
          updated_at: new Date().toISOString()
        };
      }));
      notifyWorker(currentWorker?.worker_id, incidentId, 'Work In Progress', `${assignedTeam} has started working on the incident.`);
    }, isCriticalOrHigh ? 28000 : 20000);
  };

  /**
   * Submit Text Incident
   */
  const submitText = async ({ incident_type, location, impact }) => {
    if (!currentWorker) throw new Error('You must be logged in as a worker to report an incident.');

    // Infer realistic urgency based on AI rules
    let urgency = 'Medium';
    let priority = 'Medium';

    if (incident_type === 'Temperature Breach') {
      urgency = 'Critical';
      priority = 'High';
    } else if (incident_type === 'Machine Down') {
      urgency = 'High';
      priority = 'High';
    } else if (incident_type === 'Damaged Pallet') {
      urgency = impact.toLowerCase().includes('chemical') || impact.toLowerCase().includes('leak') ? 'High' : 'Low';
      priority = urgency === 'High' ? 'High' : 'Low';
    } else if (incident_type === 'Short Shipment') {
      urgency = 'Medium';
      priority = 'Medium';
    }

    const assignedTeam = TEAM_MAPPINGS[incident_type] || 'Warehouse Handling Team';
    const initialApprovalRequired = urgency === 'High' || urgency === 'Critical';

    // 1. Send to SNS Agent Workbench Webhook
    const webhookResult = await submitTextIncident({
      worker_id: currentWorker.worker_id,
      worker_name: currentWorker.full_name,
      incident_type,
      location,
      impact
    });

    // 2. Create Incident Record (adopting backend IDs if returned by SNS Agent Workbench)
    const backendBody = webhookResult?.data?.output?.items?.[0]?.json?.body;
    const assignedWorkOrderId = backendBody?.incident_id || backendBody?.work_order_id || `WO-${Math.floor(1000 + Math.random() * 9000)}`;

    const newIncidentRecord = {
      id: `inc-${Date.now()}`,
      work_order_id: assignedWorkOrderId,
      worker_id: currentWorker.worker_id,
      worker_name: currentWorker.full_name,
      incident_type,
      location,
      impact,
      urgency,
      priority,
      responsible_team: assignedTeam,
      status: 'Submitted',
      report_mode: 'text',
      approval_required: initialApprovalRequired,
      approval_status: initialApprovalRequired ? 'Pending' : 'Not Required',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      resolved_at: null,
      events: [
        {
          time: new Date().toISOString(),
          title: 'Incident Reported',
          desc: `Reported via FieldOps Text Mode by ${currentWorker.full_name} (${currentWorker.worker_id})`,
          role: 'worker'
        }
      ]
    };

    const savedIncident = await createIncident(newIncidentRecord);
    setIncidents(prev => [savedIncident, ...prev]);

    addToast(
      'Incident Submitted',
      `Work Order ${savedIncident.work_order_id} created. AI agent is processing report...`,
      'success'
    );

    // Start background workflow simulation
    runWorkflowLifecycle(savedIncident.id, incident_type, urgency);

    return {
      success: true,
      incident: savedIncident,
      webhookResult
    };
  };

  /**
   * Submit Voice Incident
   */
  const submitVoice = async ({ audioBlob, location = 'Packing Warehouse Floor' }) => {
    if (!currentWorker) throw new Error('You must be logged in as a worker.');

    const incident_type = 'Machine Down'; // AI classifies speech
    const impact = 'Voice report received. AI speech-to-text transcription in progress.';
    const urgency = 'High';
    const assignedTeam = 'Maintenance Team';

    const webhookResult = await submitVoiceIncident({
      worker_id: currentWorker.worker_id,
      worker_name: currentWorker.full_name,
      audioBlob,
      location
    });

    const newIncidentRecord = {
      id: `inc-${Date.now()}`,
      work_order_id: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
      worker_id: currentWorker.worker_id,
      worker_name: currentWorker.full_name,
      incident_type,
      location,
      impact,
      urgency,
      priority: 'High',
      responsible_team: assignedTeam,
      status: 'Submitted',
      report_mode: 'voice',
      approval_required: true,
      approval_status: 'Pending',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      resolved_at: null,
      events: [
        {
          time: new Date().toISOString(),
          title: 'Voice Incident Reported',
          desc: `Voice audio recorded and submitted by ${currentWorker.full_name}`,
          role: 'worker'
        }
      ]
    };

    const savedIncident = await createIncident(newIncidentRecord);
    setIncidents(prev => [savedIncident, ...prev]);

    addToast(
      'Voice Report Received',
      `Audio dispatched to SNS Speech-to-Text (${savedIncident.work_order_id}).`,
      'success'
    );

    runWorkflowLifecycle(savedIncident.id, incident_type, urgency);

    return {
      success: true,
      incident: savedIncident,
      webhookResult
    };
  };

  /**
   * Manually transition incident to next state (for testing / operations / resolution)
   */
  const transitionIncident = (incidentId, newStatus) => {
    setIncidents(prev => prev.map(inc => {
      if (inc.id !== incidentId) return inc;
      const isResolved = newStatus === 'Resolved';
      const eventTitle = isResolved ? 'Incident Resolved & Closed' : `Status Changed to ${newStatus}`;
      const eventDesc = isResolved 
        ? `${inc.responsible_team || 'Response Team'} completed operational remediation on site. Normal warehouse workflow restored.`
        : `Incident updated to ${newStatus} by operational coordination.`;

      const newEvents = [
        ...(inc.events || []),
        {
          time: new Date().toISOString(),
          title: eventTitle,
          desc: eventDesc,
          role: 'team'
        }
      ];
      const updates = {
        status: newStatus,
        events: newEvents,
        updated_at: new Date().toISOString(),
        resolved_at: isResolved ? new Date().toISOString() : inc.resolved_at
      };
      updateIncident(incidentId, updates);
      
      if (isResolved) {
        notifyWorker(inc.worker_id, incidentId, 'Incident Resolved', `Work Order ${inc.work_order_id} was successfully marked as Resolved.`);
      }
      return { ...inc, ...updates };
    }));
    addToast(
      newStatus === 'Resolved' ? 'Work Completed' : 'Status Updated',
      `Incident marked as ${newStatus}`,
      'success'
    );
  };

  const markNotificationAsRead = (id) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    addToast('Notifications', 'All marked as read', 'info');
  };

  return (
    <IncidentContext.Provider
      value={{
        incidents,
        notifications,
        activeIncident,
        activeIncidentId,
        setActiveIncidentId,
        isLoading,
        stats: {
          openCount: openIncidents.length,
          myActiveCount: myActiveIncidents.length,
          awaitingApprovalCount: awaitingApproval.length,
          assignedCount: assignedToTeam.length,
          resolvedTodayCount: resolvedToday.length
        },
        submitText,
        submitVoice,
        transitionIncident,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        toasts,
        removeToast
      }}
    >
      {children}
    </IncidentContext.Provider>
  );
}

export function useIncidents() {
  const context = useContext(IncidentContext);
  if (!context) {
    throw new Error('useIncidents must be used within an IncidentProvider');
  }
  return context;
}
