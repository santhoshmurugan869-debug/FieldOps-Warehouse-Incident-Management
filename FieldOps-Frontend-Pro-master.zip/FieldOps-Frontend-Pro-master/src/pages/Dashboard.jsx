// ====================================================================
// FIELDOPS - WORKER DASHBOARD PAGE
// ====================================================================

import React from 'react';
import { 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  Users, 
  Plus, 
  ArrowRight, 
  ShieldAlert,
  Radio,
  MapPin,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useIncidents } from '../context/IncidentContext';
import StatsCard from '../components/StatsCard';
import IncidentStatusBadge from '../components/IncidentStatusBadge';
import UrgencyBadge from '../components/UrgencyBadge';
import PriorityBadge from '../components/PriorityBadge';
import StatusStepper from '../components/StatusStepper';
import TeamAssignmentCard from '../components/TeamAssignmentCard';
import { formatTime, timeAgo } from '../utils/dateUtils';

export default function Dashboard({ onNavigate, onSelectIncident }) {
  const { currentWorker } = useAuth();
  const { incidents, activeIncident, stats, notifications, transitionIncident } = useIncidents();

  // Greeting based on current hour
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const firstName = currentWorker?.full_name?.split(' ')[0] || 'Worker';

  // Gather recent operational updates across incidents
  const recentActivities = [];
  incidents.forEach(inc => {
    (inc.events || []).forEach(evt => {
      recentActivities.push({
        ...evt,
        work_order_id: inc.work_order_id,
        incident_type: inc.incident_type,
        incident_id: inc.id
      });
    });
  });
  recentActivities.sort((a, b) => new Date(b.time) - new Date(a.time));
  const latestActivities = recentActivities.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Worker Greeting Banner */}
      <div className="warehouse-card p-5 sm:p-6 bg-gradient-to-r from-white via-white to-slate-50">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
                {greeting}, {firstName} 👋
              </h2>
            </div>
            <div className="flex flex-wrap items-center gap-3 mt-1.5 text-xs text-slate-500">
              <span className="font-mono bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-semibold border border-slate-200">
                Worker ID: {currentWorker?.worker_id}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                <span>{currentWorker?.warehouse_location || 'Warehouse Station'}</span>
              </span>
              <span className="hidden md:inline">•</span>
              <span className="hidden md:inline text-slate-600">
                {currentWorker?.department}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigate('report')}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 text-white text-sm font-semibold shadow-xs transition-all shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>+ Report Incident</span>
          </button>
        </div>
      </div>

      {/* Live Operational Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <StatsCard
          label="Open Incidents"
          value={stats.openCount}
          icon={AlertTriangle}
          color="slate"
          subtext="Active warehouse-wide"
          onClick={() => onNavigate('incidents')}
        />
        <StatsCard
          label="My Active Incidents"
          value={stats.myActiveCount}
          icon={Clock}
          color="blue"
          subtext="Assigned to your queue"
          onClick={() => onNavigate('incidents')}
        />
        <StatsCard
          label="Awaiting Approval"
          value={stats.awaitingApprovalCount}
          icon={ShieldAlert}
          color="amber"
          subtext="Supervisor Telegram check"
          onClick={() => onNavigate('incidents')}
        />
        <StatsCard
          label="Assigned to Team"
          value={stats.assignedCount}
          icon={Users}
          color="indigo"
          subtext="Teams en route / working"
          onClick={() => onNavigate('incidents')}
        />
        <StatsCard
          label="Resolved Today"
          value={stats.resolvedTodayCount}
          icon={CheckCircle2}
          color="emerald"
          subtext="Operations restored"
          onClick={() => onNavigate('incidents')}
        />
      </div>

      {/* Main Two-Column Grid: Active Incident Tracker & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: My Active Incident Tracker */}
        <div className="lg:col-span-2 space-y-6">
          <div className="warehouse-card p-5 sm:p-6">
            <div className="flex items-center justify-between gap-2 pb-4 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                  My Active Incident
                </h3>
              </div>
              {activeIncident && (
                <button
                  type="button"
                  onClick={() => onSelectIncident(activeIncident.id)}
                  className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-1"
                >
                  <span>Full Details</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>

            {activeIncident ? (
              <div className="space-y-5">
                {/* Header row: Type & Location */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {activeIncident.work_order_id}
                      </span>
                      <IncidentStatusBadge status={activeIncident.status} size="sm" />
                    </div>
                    <h4 className="text-lg font-bold text-slate-900">
                      {activeIncident.incident_type}
                    </h4>
                    <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" />
                      <span>{activeIncident.location}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <UrgencyBadge urgency={activeIncident.urgency} size="md" />
                    <PriorityBadge priority={activeIncident.priority} size="md" />
                  </div>
                </div>

                {/* Impact Statement */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-700 leading-relaxed">
                  <span className="font-semibold text-slate-900">Reported Impact: </span>
                  {activeIncident.impact}
                </div>

                {/* Workflow Progression Stepper */}
                <div className="pt-2">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                    <span className="font-semibold text-slate-700 uppercase tracking-wider text-[10px]">
                      Workflow Lifecycle
                    </span>
                    <span className="text-[11px] text-blue-600 font-medium">
                      Live Coordination
                    </span>
                  </div>
                  <StatusStepper incident={activeIncident} orientation="horizontal" />
                </div>

                {/* Assigned Team Card */}
                <div className="pt-2">
                  <TeamAssignmentCard
                    teamName={activeIncident.responsible_team}
                    status={activeIncident.status}
                  />
                </div>

                {/* Quick Action to Complete or View Incident */}
                <div className="pt-2 flex flex-wrap items-center justify-end gap-2.5">
                  {activeIncident.status !== 'Resolved' && activeIncident.status !== 'Closed' ? (
                    <button
                      type="button"
                      onClick={() => transitionIncident(activeIncident.id, 'Resolved')}
                      className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-semibold shadow-xs transition-all"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Complete Work / Mark Resolved</span>
                    </button>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Incident Resolved & Operations Restored</span>
                    </span>
                  )}

                  <button
                    type="button"
                    onClick={() => onSelectIncident(activeIncident.id)}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold shadow-xs transition-colors"
                  >
                    <span>View Incident Timeline</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2 opacity-80" />
                <h4 className="text-sm font-semibold text-slate-800">All Clear on Your Floor</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  You have no pending active incidents. If you spot an issue, click the button below to report it.
                </p>
                <button
                  type="button"
                  onClick={() => onNavigate('report')}
                  className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-medium shadow-xs"
                >
                  <Plus className="w-4 h-4" />
                  <span>Report Incident</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Right 1 Col: Recent Activity Feed & Quick Actions */}
        <div className="space-y-6">
          {/* Recent Activity Feed */}
          <div className="warehouse-card p-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-2">
                <Radio className="w-4 h-4 text-blue-600" />
                <span>Recent Activity</span>
              </h3>
              <span className="text-[10px] text-slate-400 font-mono">LIVE FEED</span>
            </div>

            <div className="space-y-3.5">
              {latestActivities.map((act, index) => (
                <div 
                  key={index} 
                  onClick={() => onSelectIncident(act.incident_id)}
                  className="p-2.5 rounded-lg border border-slate-100 hover:border-slate-200 hover:bg-slate-50/70 transition-all cursor-pointer text-left"
                >
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1 font-mono">
                    <span className="font-semibold text-slate-800">{formatTime(act.time)}</span>
                    <span className="bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded text-[10px]">
                      {act.work_order_id}
                    </span>
                  </div>
                  <p className="text-xs font-semibold text-slate-800">{act.title}</p>
                  {act.desc && (
                    <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">{act.desc}</p>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Quick Action / SOP Reminder */}
          <div className="warehouse-card p-5 bg-gradient-to-br from-blue-50/50 to-indigo-50/40 border-blue-200/80">
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 mb-2">
              Warehouse Safety Reminder
            </h4>
            <p className="text-xs text-blue-800 leading-relaxed mb-3">
              In case of ammonia leaks, chemical spills, or severe temperature breaches, report via <span className="font-semibold">Voice Mode</span> immediately. AI escalates directly to Supervisor Telegram channel.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('sop')}
              className="text-xs font-semibold text-blue-700 hover:text-blue-900 inline-flex items-center gap-1"
            >
              <span>Review Warehouse SOPs</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
