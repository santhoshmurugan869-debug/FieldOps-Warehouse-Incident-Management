// ====================================================================
// FIELDOPS - MY INCIDENTS PAGE
// ====================================================================

import React, { useState } from 'react';
import { 
  Search, 
  Filter, 
  Plus, 
  PackageOpen, 
  ArrowUpDown,
  LayoutGrid,
  List
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useIncidents } from '../context/IncidentContext';
import IncidentCard from '../components/IncidentCard';
import IncidentStatusBadge from '../components/IncidentStatusBadge';
import UrgencyBadge from '../components/UrgencyBadge';
import EmptyState from '../components/EmptyState';
import { formatTime, timeAgo } from '../utils/dateUtils';

const FILTER_TABS = [
  'All',
  'Open',
  'Awaiting Approval',
  'Assigned',
  'In Progress',
  'Resolved',
  'Closed'
];

export default function MyIncidents({ onSelectIncident, onNewIncident }) {
  const { currentWorker } = useAuth();
  const { incidents } = useIncidents();

  const [activeFilter, setActiveFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'table'
  const [filterWorkerOnly, setFilterWorkerOnly] = useState(true);

  // Filter incidents
  const filtered = incidents.filter((inc) => {
    // Worker filter
    if (filterWorkerOnly && inc.worker_id !== currentWorker?.worker_id) {
      return false;
    }

    // Status filter
    if (activeFilter === 'Open') {
      if (inc.status === 'Resolved' || inc.status === 'Closed') return false;
    } else if (activeFilter === 'Awaiting Approval') {
      if (inc.status !== 'Awaiting Supervisor Approval') return false;
    } else if (activeFilter === 'Assigned') {
      if (inc.status !== 'Assigned') return false;
    } else if (activeFilter === 'In Progress') {
      if (inc.status !== 'In Progress') return false;
    } else if (activeFilter === 'Resolved') {
      if (inc.status !== 'Resolved') return false;
    } else if (activeFilter === 'Closed') {
      if (inc.status !== 'Closed') return false;
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchType = inc.incident_type?.toLowerCase().includes(q);
      const matchLoc = inc.location?.toLowerCase().includes(q);
      const matchImpact = inc.impact?.toLowerCase().includes(q);
      const matchWO = inc.work_order_id?.toLowerCase().includes(q);
      const matchTeam = inc.responsible_team?.toLowerCase().includes(q);
      return matchType || matchLoc || matchImpact || matchWO || matchTeam;
    }

    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
            Incident Log & History
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Track real-time resolution status and team movements across your warehouse operations.
          </p>
        </div>

        <button
          type="button"
          onClick={onNewIncident}
          className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Report Incident</span>
        </button>
      </div>

      {/* Filter Tabs & Search Bar */}
      <div className="warehouse-card p-4 space-y-4">
        {/* Top Controls: Search & Scope Toggle */}
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between">
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by Work Order, location, type..."
              className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
            {/* Scope Switcher: My queue vs Warehouse-wide */}
            <div className="flex rounded-lg bg-slate-100 p-0.5 border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setFilterWorkerOnly(true)}
                className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                  filterWorkerOnly
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                My Incidents ({incidents.filter(i => i.worker_id === currentWorker?.worker_id).length})
              </button>
              <button
                type="button"
                onClick={() => setFilterWorkerOnly(false)}
                className={`px-3 py-1.5 rounded-md font-medium transition-all ${
                  !filterWorkerOnly
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Warehouse ({incidents.length})
              </button>
            </div>

            {/* View Mode Toggle */}
            <div className="hidden sm:flex rounded-lg bg-slate-100 p-0.5 border border-slate-200">
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-md ${
                  viewMode === 'grid' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'
                }`}
                title="Grid View"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-md ${
                  viewMode === 'table' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'
                }`}
                title="Table View"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Filter Badges Horizontal Scroll */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 pt-1 border-t border-slate-100">
          {FILTER_TABS.map((tab) => {
            const isActive = activeFilter === tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveFilter(tab)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab}
              </button>
            );
          })}
        </div>
      </div>

      {/* Incident List / Cards */}
      {filtered.length === 0 ? (
        <EmptyState
          title="No incidents match your filter"
          description={
            searchQuery
              ? `No operational incidents match "${searchQuery}". Try modifying your search criteria.`
              : `There are currently no incidents with status "${activeFilter}".`
          }
          actionText="+ Report New Incident"
          onAction={onNewIncident}
        />
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((inc) => (
            <IncidentCard
              key={inc.id}
              incident={inc}
              onSelect={onSelectIncident}
            />
          ))}
        </div>
      ) : (
        /* Table View */
        <div className="warehouse-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold tracking-wider text-[10px]">
                <tr>
                  <th className="py-3 px-4">Work Order</th>
                  <th className="py-3 px-4">Incident Type</th>
                  <th className="py-3 px-4">Location</th>
                  <th className="py-3 px-4">Urgency</th>
                  <th className="py-3 px-4">Assigned Team</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4">Reported</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filtered.map((inc) => (
                  <tr
                    key={inc.id}
                    onClick={() => onSelectIncident(inc.id)}
                    className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                  >
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                      {inc.work_order_id}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900">
                      {inc.incident_type}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 truncate max-w-[150px]">
                      {inc.location}
                    </td>
                    <td className="py-3.5 px-4">
                      <UrgencyBadge urgency={inc.urgency} size="sm" />
                    </td>
                    <td className="py-3.5 px-4 font-medium text-slate-700">
                      {inc.responsible_team || 'Pending'}
                    </td>
                    <td className="py-3.5 px-4">
                      <IncidentStatusBadge status={inc.status} size="sm" />
                    </td>
                    <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                      {timeAgo(inc.created_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
