// ====================================================================
// FIELDOPS - NOTIFICATIONS PAGE
// ====================================================================

import React, { useState } from 'react';
import { 
  Bell, 
  CheckCheck, 
  Clock, 
  ArrowRight, 
  Filter, 
  ShieldCheck, 
  Users, 
  Wrench,
  CheckCircle2
} from 'lucide-react';
import { useIncidents } from '../context/IncidentContext';
import { timeAgo, formatDateTime } from '../utils/dateUtils';
import EmptyState from '../components/EmptyState';

export default function Notifications({ onSelectIncident }) {
  const { notifications, markNotificationAsRead, markAllNotificationsAsRead } = useIncidents();
  const [filterUnread, setFilterUnread] = useState(false);

  const displayed = filterUnread ? notifications.filter(n => !n.read) : notifications;
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
              Operational Notifications
            </h2>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-blue-600 text-white">
                {unreadCount} new
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time dispatches, supervisor approvals, and team movement alerts.
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            type="button"
            onClick={markAllNotificationsAsRead}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-xs font-semibold text-slate-700 shadow-2xs transition-colors shrink-0"
          >
            <CheckCheck className="w-4 h-4 text-slate-500" />
            <span>Mark All as Read</span>
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2 text-xs">
          <button
            type="button"
            onClick={() => setFilterUnread(false)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              !filterUnread ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            All Alerts ({notifications.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterUnread(true)}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
              filterUnread ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            Unread Only ({unreadCount})
          </button>
        </div>
      </div>

      {/* Notifications List */}
      {displayed.length === 0 ? (
        <EmptyState
          icon={Bell}
          title="No alerts to display"
          description={filterUnread ? "You have caught up with all operational alerts." : "No notifications have been recorded yet."}
        />
      ) : (
        <div className="space-y-3">
          {displayed.map((item) => (
            <div
              key={item.id}
              onClick={() => {
                markNotificationAsRead(item.id);
                if (item.incident_id && onSelectIncident) {
                  onSelectIncident(item.incident_id);
                }
              }}
              className={`warehouse-card p-4 flex items-start justify-between gap-4 cursor-pointer transition-all ${
                !item.read ? 'bg-blue-50/40 border-blue-200/80 shadow-xs' : 'hover:border-slate-300'
              }`}
            >
              <div className="flex items-start gap-3 min-w-0">
                <div className={`p-2 rounded-xl mt-0.5 shrink-0 ${
                  !item.read ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  <Bell className="w-4 h-4" />
                </div>

                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className={`text-sm font-semibold truncate ${
                      !item.read ? 'text-slate-900 font-bold' : 'text-slate-800'
                    }`}>
                      {item.title}
                    </h4>
                    {!item.read && (
                      <span className="w-2 h-2 rounded-full bg-blue-600 shrink-0" />
                    )}
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.message}
                  </p>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-2 font-mono">
                    <span>{timeAgo(item.created_at)}</span>
                    <span>•</span>
                    <span>{formatDateTime(item.created_at)}</span>
                  </div>
                </div>
              </div>

              <div className="shrink-0 flex items-center text-slate-400 hover:text-blue-600 pt-1">
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
