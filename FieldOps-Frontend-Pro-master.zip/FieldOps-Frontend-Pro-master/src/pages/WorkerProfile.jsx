// ====================================================================
// FIELDOPS - WORKER PROFILE PAGE
// ====================================================================

import React, { useState } from 'react';
import { 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  Briefcase, 
  Calendar, 
  ShieldCheck, 
  Edit3, 
  Save, 
  CheckCircle2,
  Building,
  LogOut,
  ShieldAlert
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useIncidents } from '../context/IncidentContext';
import WorkerAvatar from '../components/WorkerAvatar';
import Modal from '../components/Modal';
import { WAREHOUSE_LOCATIONS } from '../utils/constants';

export default function WorkerProfile() {
  const { currentWorker, updateProfile, logout } = useAuth();
  const { incidents } = useIncidents();

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    phone: currentWorker?.phone || '',
    warehouse_location: currentWorker?.warehouse_location || '',
    department: currentWorker?.department || ''
  });

  const workerIncidents = incidents.filter(i => i.worker_id === currentWorker?.worker_id);
  const resolvedCount = workerIncidents.filter(i => i.status === 'Resolved' || i.status === 'Closed').length;

  const handleOpenEdit = () => {
    setFormData({
      phone: currentWorker?.phone || '',
      warehouse_location: currentWorker?.warehouse_location || '',
      department: currentWorker?.department || ''
    });
    setIsEditModalOpen(true);
  };

  const handleSave = (e) => {
    e.preventDefault();
    updateProfile(formData);
    setIsEditModalOpen(false);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Profile Header Card */}
      <div className="warehouse-card p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-4">
            <WorkerAvatar
              name={currentWorker?.full_name}
              id={currentWorker?.worker_id}
              size="xl"
            />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                  {currentWorker?.full_name}
                </h2>
                <span className="text-xs bg-emerald-50 text-emerald-700 font-semibold px-2 py-0.5 rounded-full border border-emerald-200">
                  Active
                </span>
              </div>
              <p className="font-mono text-xs font-bold text-blue-600 mt-0.5">
                {currentWorker?.worker_id} • {currentWorker?.role || 'Warehouse Worker'}
              </p>
              <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-1">
                <Building className="w-3.5 h-3.5 text-slate-400" />
                <span>{currentWorker?.department}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={handleOpenEdit}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 shadow-2xs transition-colors shrink-0"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Edit Profile</span>
          </button>
        </div>

        {/* Profile Details Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-6 text-xs">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
            <Mail className="w-4 h-4 text-slate-400 shrink-0" />
            <div>
              <p className="text-slate-400 text-[11px]">Email Address</p>
              <p className="font-medium text-slate-800">{currentWorker?.email}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
            <Phone className="w-4 h-4 text-slate-400 shrink-0" />
            <div>
              <p className="text-slate-400 text-[11px]">Contact Phone</p>
              <p className="font-medium text-slate-800">{currentWorker?.phone || 'Not specified'}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
            <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
            <div>
              <p className="text-slate-400 text-[11px]">Assigned Warehouse Hub</p>
              <p className="font-medium text-slate-800">{currentWorker?.warehouse_location}</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
            <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
            <div>
              <p className="text-slate-400 text-[11px]">Warehouse Onboarding Date</p>
              <p className="font-medium text-slate-800">{currentWorker?.joined_date || '2025-01-10'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Operational Stats for Current Worker */}
      <div className="grid grid-cols-3 gap-4">
        <div className="warehouse-card p-4 text-center">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Reported</span>
          <p className="text-2xl font-bold font-mono text-slate-900 mt-1">{workerIncidents.length}</p>
        </div>
        <div className="warehouse-card p-4 text-center">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Resolved</span>
          <p className="text-2xl font-bold font-mono text-emerald-600 mt-1">{resolvedCount}</p>
        </div>
        <div className="warehouse-card p-4 text-center">
          <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Safety Rating</span>
          <p className="text-2xl font-bold font-mono text-blue-600 mt-1">100%</p>
        </div>
      </div>

      {/* Account Session & Sign Out */}
      <div className="warehouse-card p-5 bg-white border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
              Active Terminal Session
            </h4>
            <p className="text-xs text-slate-500 mt-1">
              Logged in as <span className="font-semibold text-slate-800">{currentWorker?.full_name}</span> (Worker ID: <span className="font-mono font-semibold text-blue-600">{currentWorker?.worker_id}</span>)
            </p>
          </div>
          <button
            type="button"
            onClick={logout}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-semibold transition-colors shrink-0"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out of Terminal</span>
          </button>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        title="Edit Worker Profile"
        subtitle="Update non-sensitive contact and assignment details"
      >
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Contact Phone
            </label>
            <input
              type="text"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Assigned Warehouse Hub
            </label>
            <select
              value={formData.warehouse_location}
              onChange={(e) => setFormData({ ...formData, warehouse_location: e.target.value })}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {WAREHOUSE_LOCATIONS.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
              Department
            </label>
            <input
              type="text"
              value={formData.department}
              onChange={(e) => setFormData({ ...formData, department: e.target.value })}
              className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsEditModalOpen(false)}
              className="px-4 py-2 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 shadow-xs flex items-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Profile</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
