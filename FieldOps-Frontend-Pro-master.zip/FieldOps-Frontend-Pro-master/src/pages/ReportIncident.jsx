// ====================================================================
// FIELDOPS - REPORT INCIDENT PAGE
// Dual Text & Voice Reporting with Browser Audio
// ====================================================================

import React, { useState } from 'react';
import { 
  FileText, 
  Mic, 
  MapPin, 
  AlertCircle, 
  Send, 
  Sparkles, 
  ShieldAlert, 
  Check, 
  Info 
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useIncidents } from '../context/IncidentContext';
import VoiceReportButton from '../components/VoiceReportButton';
import { INCIDENT_TYPES, WAREHOUSE_LOCATIONS } from '../utils/constants';

export default function ReportIncident({ onIncidentCreated }) {
  const { currentWorker } = useAuth();
  const { submitText, submitVoice } = useIncidents();

  const [mode, setMode] = useState('text'); // 'text' | 'voice'
  const [formData, setFormData] = useState({
    incident_type: 'Damaged Pallet',
    location: WAREHOUSE_LOCATIONS[0],
    impact: ''
  });
  const [customLocation, setCustomLocation] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState(null);

  const handleTextSubmit = async (e) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!formData.incident_type) {
      setErrorMessage('Please select an Incident Type.');
      return;
    }
    if (!formData.location.trim()) {
      setErrorMessage('Please specify the incident location.');
      return;
    }
    if (!formData.impact.trim() || formData.impact.trim().length < 5) {
      setErrorMessage('Please provide a brief description of the operational impact.');
      return;
    }

    try {
      setIsSubmitting(true);
      const result = await submitText({
        incident_type: formData.incident_type,
        location: formData.location.trim(),
        impact: formData.impact.trim()
      });

      if (result.success && onIncidentCreated) {
        onIncidentCreated(result.incident.id);
      }
    } catch (err) {
      console.error('Submit incident failed:', err);
      setErrorMessage(err.message || 'Unable to submit incident right now. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleVoiceSubmit = async (audioBlob) => {
    setErrorMessage(null);
    try {
      setIsSubmitting(true);
      const result = await submitVoice({
        audioBlob,
        location: formData.location || currentWorker?.warehouse_location || 'Warehouse Floor'
      });

      if (result.success && onIncidentCreated) {
        onIncidentCreated(result.incident.id);
      }
    } catch (err) {
      console.error('Voice submission failed:', err);
      setErrorMessage(err.message || 'Failed to submit voice recording.');
      throw err;
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Page Header */}
      <div>
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
          Report Warehouse Incident
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Submit immediate operational issues. AI Agent automatically classifies urgency and routes to the responsible team.
        </p>
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex rounded-xl bg-slate-200/80 p-1 border border-slate-200 shadow-2xs">
        <button
          type="button"
          onClick={() => setMode('text')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            mode === 'text'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileText className="w-4 h-4 text-blue-600" />
          <span>Text Report</span>
        </button>

        <button
          type="button"
          onClick={() => setMode('voice')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-semibold transition-all ${
            mode === 'voice'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Mic className="w-4 h-4 text-purple-600" />
          <span>Voice Report (Microphone)</span>
        </button>
      </div>

      {/* Authenticated Worker Attribution Card */}
      <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200/70 flex items-center justify-between text-xs text-blue-900">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-mono flex items-center justify-center font-bold text-xs">
            {currentWorker?.worker_id?.slice(-2) || 'ID'}
          </div>
          <div>
            <p className="font-semibold text-slate-900">
              Submitting as: <span className="text-blue-800">{currentWorker?.full_name}</span>
            </p>
            <p className="text-[11px] text-slate-500 font-mono">
              Worker ID: {currentWorker?.worker_id} • {currentWorker?.warehouse_location}
            </p>
          </div>
        </div>
        <span className="hidden sm:inline-flex items-center gap-1 text-[11px] text-blue-700 bg-white/80 px-2 py-0.5 rounded border border-blue-200 font-medium">
          <Check className="w-3 h-3 text-emerald-600" />
          Verified Identity
        </span>
      </div>

      {/* Error Alert */}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs text-red-800 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold">Unable to submit incident</p>
            <p className="mt-0.5 leading-relaxed">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* Mode 1: Text Report Form */}
      {mode === 'text' && (
        <form onSubmit={handleTextSubmit} className="warehouse-card p-5 sm:p-6 space-y-5">
          {/* Incident Type Dropdown */}
          <div>
            <label htmlFor="incident_type" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
              Incident Type <span className="text-red-500">*</span>
            </label>
            <select
              id="incident_type"
              value={formData.incident_type}
              onChange={(e) => setFormData({ ...formData, incident_type: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              {INCIDENT_TYPES.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
            <p className="text-[11px] text-slate-400 mt-1">
              Select the primary category of disruption observed.
            </p>
          </div>

          {/* Location Selection with Presets */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="location" className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                Location <span className="text-red-500">*</span>
              </label>
              <button
                type="button"
                onClick={() => setCustomLocation(!customLocation)}
                className="text-[11px] font-semibold text-blue-600 hover:text-blue-800"
              >
                {customLocation ? 'Choose from warehouse presets' : 'Enter custom location'}
              </button>
            </div>

            {customLocation ? (
              <input
                id="location"
                type="text"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                placeholder="e.g. Packing Line 3, Bay B12"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            ) : (
              <select
                id="location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              >
                {WAREHOUSE_LOCATIONS.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Impact Textarea */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label htmlFor="impact" className="block text-xs font-bold uppercase tracking-wider text-slate-700">
                Operational Impact <span className="text-red-500">*</span>
              </label>
              <span className="text-[11px] text-slate-400 font-mono">
                {formData.impact.length} chars
              </span>
            </div>
            <textarea
              id="impact"
              rows={4}
              value={formData.impact}
              onChange={(e) => setFormData({ ...formData, impact: e.target.value })}
              placeholder="Describe what happened, equipment jammed, delayed orders, safety hazards..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 leading-relaxed"
              required
            />
            <div className="flex flex-wrap items-center gap-1.5 mt-2">
              <span className="text-[11px] text-slate-400">Quick suggestions:</span>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, impact: 'Packing machine stopped and around 30 orders are delayed.' })}
                className="text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
              >
                Machine jammed (30 orders)
              </button>
              <button
                type="button"
                onClick={() => setFormData({ ...formData, impact: 'Forklift tilt damaged pallet shrink wrap. 4 cartons crushed.' })}
                className="text-[11px] px-2 py-0.5 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
              >
                Crushed cartons
              </button>
            </div>
          </div>

          {/* Automated AI & Supervisor Note */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-start gap-2.5">
            <Sparkles className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-slate-800">Automated AI Assessment</p>
              <p className="mt-0.5 text-[11px] text-slate-500 leading-relaxed">
                Urgency & Priority are classified automatically by AI based on operational impact. High & Critical incidents are routed to Telegram for Supervisor Approval.
              </p>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white font-semibold text-sm shadow-sm flex items-center justify-center gap-2 disabled:opacity-50 transition-all"
            >
              {isSubmitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Submitting Incident to AI Agent...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Submit Incident Report</span>
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* Mode 2: Voice Report Form */}
      {mode === 'voice' && (
        <div className="space-y-4">
          <div className="warehouse-card p-5 sm:p-6">
            <div className="mb-5">
              <label htmlFor="voice_location" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Current Location
              </label>
              <select
                id="voice_location"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {WAREHOUSE_LOCATIONS.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>

            <VoiceReportButton
              isSubmitting={isSubmitting}
              onSubmit={handleVoiceSubmit}
            />
          </div>

          <div className="p-4 rounded-xl bg-purple-50/60 border border-purple-200 text-xs text-purple-900 flex items-start gap-3">
            <Info className="w-5 h-5 text-purple-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">How Voice Reporting Works</p>
              <p className="mt-0.5 text-purple-800 leading-relaxed text-[11px]">
                Your audio recording is streamed directly to the SNS Agent Workbench Webhook. The AI speech model transcribes the report, extracts incident type, location, and impact, and immediately coordinates team dispatch.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
