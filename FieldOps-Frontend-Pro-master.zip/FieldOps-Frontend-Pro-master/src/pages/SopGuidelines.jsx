// ====================================================================
// FIELDOPS - WAREHOUSE SOP & COORDINATION GUIDELINES
// ====================================================================

import React from 'react';
import { 
  BookOpen, 
  ShieldAlert, 
  Users, 
  Cpu, 
  Send, 
  CheckCircle2, 
  AlertTriangle,
  Radio,
  FileText
} from 'lucide-react';
import { TEAM_MAPPINGS, TEAM_DETAILS, URGENCY_LEVELS } from '../utils/constants';

export default function SopGuidelines() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900">
          Warehouse Standard Operating Procedures (SOP)
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Reference guide for incident classification, urgency thresholds, and team routing rules.
        </p>
      </div>

      {/* Core Principle Card */}
      <div className="warehouse-card p-6 bg-gradient-to-r from-blue-50/70 via-indigo-50/50 to-white border-blue-200">
        <h3 className="text-xs font-bold uppercase tracking-wider text-blue-900 mb-2">
          Core Operating Principle
        </h3>
        <p className="text-sm font-semibold text-slate-900 leading-relaxed">
          AI understands. Rules decide. Humans approve critical actions. Automation executes. Every incident is tracked.
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 mt-4 text-center text-xs">
          <div className="p-2.5 rounded-lg bg-white/80 border border-blue-100">
            <span className="font-bold text-blue-700 block">1. Report</span>
            <span className="text-[11px] text-slate-500">Text or Voice</span>
          </div>
          <div className="p-2.5 rounded-lg bg-white/80 border border-blue-100">
            <span className="font-bold text-purple-700 block">2. AI Extract</span>
            <span className="text-[11px] text-slate-500">Type & Location</span>
          </div>
          <div className="p-2.5 rounded-lg bg-white/80 border border-blue-100">
            <span className="font-bold text-amber-700 block">3. Approval</span>
            <span className="text-[11px] text-slate-500">Telegram Check</span>
          </div>
          <div className="p-2.5 rounded-lg bg-white/80 border border-blue-100">
            <span className="font-bold text-indigo-700 block">4. Dispatch</span>
            <span className="text-[11px] text-slate-500">Auto Team Route</span>
          </div>
          <div className="p-2.5 rounded-lg bg-white/80 border border-blue-100 col-span-2 sm:col-span-1">
            <span className="font-bold text-emerald-700 block">5. Resolve</span>
            <span className="text-[11px] text-slate-500">Floor Update</span>
          </div>
        </div>
      </div>

      {/* Team Assignment Matrix */}
      <div className="warehouse-card p-6">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800 mb-4 flex items-center gap-2">
          <Users className="w-4 h-4 text-blue-600" />
          <span>Automated Team Routing Matrix</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase font-semibold text-[10px]">
              <tr>
                <th className="py-3 px-4">Incident Type</th>
                <th className="py-3 px-4">Assigned Team</th>
                <th className="py-3 px-4">Duty Lead</th>
                <th className="py-3 px-4">Comms Channel</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {Object.entries(TEAM_MAPPINGS).map(([type, teamName]) => {
                const details = TEAM_DETAILS[teamName];
                return (
                  <tr key={type} className="hover:bg-slate-50/60">
                    <td className="py-3.5 px-4 font-semibold text-slate-900">{type}</td>
                    <td className="py-3.5 px-4 font-medium text-blue-700">{teamName}</td>
                    <td className="py-3.5 px-4 text-slate-600">{details?.lead || 'Team Lead'}</td>
                    <td className="py-3.5 px-4 font-mono text-slate-500">{details?.contact}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Urgency Classification Rules */}
      <div className="warehouse-card p-6 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-800 mb-3 flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-amber-600" />
          <span>Urgency Classification & Escalation Rules</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          {Object.entries(URGENCY_LEVELS).map(([key, item]) => (
            <div key={key} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="flex items-center justify-between mb-1.5">
                <span className={`px-2.5 py-0.5 rounded font-bold uppercase ${item.badgeClass}`}>
                  {key}
                </span>
                {item.requiresApproval && (
                  <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 font-medium">
                    Telegram Approval Required
                  </span>
                )}
              </div>
              <p className="text-slate-600 mt-2 leading-relaxed">{item.description}</p>
            </div>
          ))}
        </div>

        <div className="p-4 rounded-xl bg-orange-50 border border-orange-200 text-xs text-orange-900">
          <p className="font-bold">Important Supervisor Rejection Rule:</p>
          <p className="mt-1 leading-relaxed text-[11px] text-orange-800">
            If a supervisor rejects a High/Critical incident via Telegram, the incident <span className="font-bold">MUST NOT be closed</span>. It continues through normal warehouse resolution to ensure operational follow-up without safety risks.
          </p>
        </div>
      </div>
    </div>
  );
}
