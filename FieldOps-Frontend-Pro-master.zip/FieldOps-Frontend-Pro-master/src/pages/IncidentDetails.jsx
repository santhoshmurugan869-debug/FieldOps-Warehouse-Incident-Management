// ====================================================================
// FIELDOPS - INCIDENT DETAILS & TIMELINE PAGE
// ====================================================================

import React from 'react';
import { 
  ArrowLeft, 
  Clock, 
  MapPin, 
  User, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldAlert, 
  Calendar, 
  FileText, 
  Mic, 
  Radio, 
  Wrench,
  ChevronRight,
  Sparkles,
  Play
} from 'lucide-react';
import { useIncidents } from '../context/IncidentContext';
import IncidentStatusBadge from '../components/IncidentStatusBadge';
import UrgencyBadge from '../components/UrgencyBadge';
import PriorityBadge from '../components/PriorityBadge';
import StatusStepper from '../components/StatusStepper';
import TeamAssignmentCard from '../components/TeamAssignmentCard';
import ActivityTimeline from '../components/ActivityTimeline';
import { formatDateTime, timeAgo } from '../utils/dateUtils';
import { URGENCY_LEVELS } from '../utils/constants';

export default function IncidentDetails({ incidentId, onBack }) {
  const { incidents, transitionIncident } = useIncidents();

  const incident = incidents.find(i => i.id === incidentId);

  if (!incident) {
    return (
      <div className="warehouse-card p-12 text-center">
        <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
        <h3 className="text-base font-semibold text-slate-800">Incident Not Found</h3>
        <p className="text-xs text-slate-500 mt-1">The requested incident could not be retrieved.</p>
        <button
          type="button"
          onClick={onBack}
          className="mt-4 px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold"
        >
          Return to Dashboard
        </button>
      </div>
    );
  }

  const urgencyDetails = URGENCY_LEVELS[incident.urgency] || URGENCY_LEVELS.Medium;

  // Simulator handler to advance workflow stages on demand
  const handleSimulateUpdate = (targetStatus, eventTitle, eventDesc) => {
    transitionIncident(incident.id, targetStatus);
  };

  return (
    <div className="space-y-6">
      {/* Back Button & Top Navigation */}
      <div className="flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Operations</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="font-mono text-xs text-slate-500 bg-white border border-slate-200 px-2 py-1 rounded-md">
            ID: {incident.id.slice(0, 12)}
          </span>
          <span className="font-mono text-xs font-bold text-slate-900 bg-slate-100 border border-slate-200 px-2.5 py-1 rounded-md">
            {incident.work_order_id}
          </span>
        </div>
      </div>

      {/* Main Incident Banner */}
      <div className="warehouse-card p-6">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <IncidentStatusBadge status={incident.status} size="lg" />
              <UrgencyBadge urgency={incident.urgency} size="lg" />
              <PriorityBadge priority={incident.priority} size="md" />
              {incident.report_mode === 'voice' && (
                <span className="inline-flex items-center gap-1 text-xs text-purple-700 bg-purple-50 border border-purple-200 px-2 py-1 rounded-full font-medium">
                  <Mic className="w-3.5 h-3.5" />
                  Voice Reported
                </span>
              )}
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900">
              {incident.incident_type}
            </h1>

            <p className="text-xs sm:text-sm text-slate-500 flex items-center gap-1.5 mt-1">
              <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
              <span>{incident.location}</span>
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-end sm:items-center gap-3 shrink-0">
            {incident.status !== 'Resolved' && incident.status !== 'Closed' ? (
              <button
                type="button"
                onClick={() => handleSimulateUpdate('Resolved')}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs font-bold shadow-xs transition-all"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Complete Work / Mark Resolved</span>
              </button>
            ) : (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Resolved</span>
              </span>
            )}
            <div className="text-right text-xs text-slate-400">
              <p className="font-medium text-slate-700">Reported {timeAgo(incident.created_at)}</p>
              <p className="font-mono text-[11px] mt-0.5">{formatDateTime(incident.created_at)}</p>
            </div>
          </div>
        </div>

        {/* Workflow Progression Stepper Header */}
        <div className="pt-5">
          <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">
            Warehouse Work Coordination Progress
          </h4>
          <StatusStepper incident={incident} orientation="horizontal" />
        </div>
      </div>

      {/* Two Column Layout: Details & Activity Timeline */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 1 Col: Key Metadata & Team Card */}
        <div className="space-y-6">
          {/* Team Assignment Card */}
          <TeamAssignmentCard
            teamName={incident.responsible_team}
            status={incident.status}
          />

          {/* Core Incident Specifications */}
          <div className="warehouse-card p-5 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 border-b border-slate-100 pb-2">
              Incident Metadata
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <p className="text-slate-400">Reporting Worker</p>
                <p className="font-semibold text-slate-800 mt-0.5">
                  {incident.worker_name} ({incident.worker_id})
                </p>
              </div>

              <div>
                <p className="text-slate-400">Report Mode</p>
                <p className="font-medium text-slate-800 mt-0.5 capitalize">
                  {incident.report_mode || 'Text'} Mode
                </p>
              </div>

              <div>
                <p className="text-slate-400">Supervisor Telegram Approval</p>
                <div className="mt-1">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold ${
                    incident.approval_status === 'Approved'
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : incident.approval_status === 'Pending'
                      ? 'bg-amber-50 text-amber-800 border border-amber-200'
                      : incident.approval_status === 'Rejected'
                      ? 'bg-orange-50 text-orange-800 border border-orange-200'
                      : 'bg-slate-100 text-slate-600'
                  }`}>
                    {incident.approval_status}
                  </span>
                </div>
              </div>

              <div>
                <p className="text-slate-400">Urgency Classification</p>
                <p className="text-[11px] text-slate-600 mt-1 leading-relaxed bg-slate-50 p-2 rounded border border-slate-100">
                  {urgencyDetails.description}
                </p>
              </div>
            </div>
          </div>

          {/* Operational Demo Simulation Actions (to easily test updates) */}
          <div className="warehouse-card p-5 bg-slate-50/70 border-dashed">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>Coordination Simulation</span>
            </h4>
            <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
              Manually advance the work coordination state to verify real-time status transitions and timeline updates:
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleSimulateUpdate('In Progress')}
                className="px-2.5 py-1.5 rounded-lg bg-white border border-slate-300 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 transition-colors text-left"
              >
                ● Work In Progress
              </button>
              <button
                type="button"
                onClick={() => handleSimulateUpdate('Resolved')}
                className="px-2.5 py-1.5 rounded-lg bg-emerald-600 text-white text-[11px] font-semibold hover:bg-emerald-700 transition-colors text-left shadow-2xs"
              >
                ✓ Mark Resolved
              </button>
            </div>
          </div>
        </div>

        {/* Right 2 Cols: Reported Impact & Activity Timeline */}
        <div className="lg:col-span-2 space-y-6">
          {/* Operational Impact Statement */}
          <div className="warehouse-card p-5 sm:p-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 mb-2">
              Operational Impact Description
            </h3>
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-sm text-slate-800 leading-relaxed">
              {incident.impact}
            </div>
          </div>

          {/* Activity Timeline (Extremely Important) */}
          <div className="warehouse-card p-5 sm:p-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Incident Activity Timeline
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Chronological record of AI extraction, supervisor actions, and team response.
                </p>
              </div>
              <span className="text-xs font-mono font-semibold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
                {(incident.events || []).length} Milestones
              </span>
            </div>

            <ActivityTimeline events={incident.events} incidentId={incident.id} />
          </div>
        </div>
      </div>
    </div>
  );
}
